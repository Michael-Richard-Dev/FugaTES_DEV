# R139 — approved R135D implementation

Authorization: user approved this isolated staging and offline QA.

1. Baseline: copied allowlisted source/resources and three focal suites; no private JSON, bin/obj, repository metadata or installed files.
2. RED tests pending.
3. Implement transaction/data source, desktop composition and alternative route protection.
4. GREEN/build/review/package pending.

Ruling: use a copy of the current uncommitted staging, not a Git worktree from a historical commit; explicit user isolation requirement. No commits/publish/real I/O.
Ruling: add an explicit read-only preflight control to the existing form; do not manufacture journal attestation to enable CREATE.
Ruling: only focal regressions; network-dependent old tests are excluded under NO_DATABASE_CONNECTION.

Task 1 complete: R135D SHA256 matched; current staging source copied with explicit user authorization. R135B/R132 reference identity retained; R73 not used as baseline.
Task 2 complete: watched red-initial 11 fail/1 pass (missing ADO seam), red-boundary 4 fail/8 pass (missing transaction acknowledgement); green transaction 12 pass. DbDataSource standard seam changes only parameter plumbing; existing Npgsql callers remain source compatible, all dependencies rebuilt.
Task 3 complete: explicit preflight + controller shared lock + R41 BindAsync route; dedicated identity/profile pool, Enlist=false; no runtime profile emitted, no default writer enablement. Default source requirements and operational approval stay blocked.
Task 4 complete: first-party candidate automatic Host registration and desktop polling blocked in unitary mode. Other installed processes not attested; physical writer exclusion is a deployment preflight requirement.
Task 5 complete: final review found profile snapshot revocation, UI result loss and encoding issue; all fixed. Red review-revocation test failed before fix. 31 R139 Release tests passed, including post-PREPARED revocation, lease identity/read failure and persistent sanitized UI state.
Task 6 complete: selected R105 regressions 74 pass; selected R41 regressions 8 pass. Prior 75-test run had four missing-fixture/root errors: copied original solution marker resolved three; private R117-dependent test excluded instead of exporting private config. Two old unreachable-database tests excluded under NO_DATABASE_CONNECTION. No whole historical suite rerun.
Task 7 complete: Release WinForms build succeeded, zero warnings/errors. No publish or application startup. Review confirmation: no remaining issue in corrected scope. Physical constraints, COMMIT, dedicated HML instance and independent writers remain PENDING_PHYSICAL_VALIDATION.
Ruling: do not execute tests that open even an unreachable TCP database connection; substitute journal control-flow tests over real production class + ADO.NET doubles, never a physical durability claim.
Ruling: use current profile lease with immutable snapshot and fresh reload; any profile changes require new explicit preflight, never silent pool rebinding.
