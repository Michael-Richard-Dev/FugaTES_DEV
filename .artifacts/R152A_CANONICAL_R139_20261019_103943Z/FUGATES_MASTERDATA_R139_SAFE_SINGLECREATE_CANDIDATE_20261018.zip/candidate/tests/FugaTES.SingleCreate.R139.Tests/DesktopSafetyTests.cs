using System.Net;
using System.Transactions;
using FugaTES.Aplicacao.Transportadoras.SingleCreateR31;
using FugaTES.HostIntegracao;
using FugaTES.WinForms.Runtime;
using FugaTES.WinForms.Transportadoras;
using FugaTES.WinForms.Transportadoras.MasterdataR3;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;

namespace FugaTES.SingleCreate.R139.Tests;

public class DesktopSafetyTests
{
    static readonly ProntidaoSingleCreateR122 Yes=new(true,[]);
    static SingleCreateDatabaseProfileR139 Profile()=>new("HML",true,"SYNTHETIC_TARGET_APPROVAL","127.0.0.1",5434,"synthetic_masterdata","synthetic_app","fugates");
    const string Existing="Host=127.0.0.1;Port=5434;Database=synthetic_masterdata;Username=synthetic_app;Enlist=true;Options=-c default_transaction_read_only=on";

    [Fact] public void Dedicated_options_disable_enlistment_without_mutating_general_pool()
    {
        using var scope=new TransactionScope(TransactionScopeAsyncFlowOption.Enabled);
        var dedicated=Profile().Options(Existing);
        Assert.False(dedicated.Enlist);Assert.True(new NpgsqlConnectionStringBuilder(Existing).Enlist);
        Assert.Equal("FugaTES.Desktop.SingleCreate.HML",dedicated.ApplicationName);
        Assert.Contains("default_transaction_read_only=off",dedicated.Options);
        Assert.NotNull(Transaction.Current); // Properties only; no connection is opened in the scope.
        using var source=NpgsqlDataSource.Create(dedicated.ConnectionString);
        Assert.False(new NpgsqlConnectionStringBuilder(source.ConnectionString).Enlist);
    }
    [Theory]
    [InlineData(5432,"fugates_dev","fugates_dev_app")]
    [InlineData(5433,"synthetic_masterdata","synthetic_app")]
    [InlineData(0,"synthetic_masterdata","synthetic_app")]
    public void Original_acm_or_unspecified_endpoint_cannot_be_reused(int port,string db,string role)
        =>Assert.Throws<DesktopStartupException>(()=>(Profile() with{Port=port,Database=db,Role=role}).Options(Existing));
    [Fact] public void Unapproved_or_mismatching_identity_never_redirects_connection()
    {
        Assert.Throws<DesktopStartupException>(()=>(Profile() with{Approved=false}).Options(Existing));
        Assert.Throws<DesktopStartupException>(()=>(Profile() with{Role="other_app"}).Options(Existing));
        Assert.Throws<DesktopStartupException>(()=>(Profile() with{Environment="DEV"}).Options(Existing));
        Assert.Throws<DesktopStartupException>(()=>SingleCreateDatabaseProfileR139.Load(new ConfigurationBuilder().Build()).Options(Existing));
    }
    [Fact] public async Task Missing_authorization_or_preflight_never_composes_session()
    {
        var calls=0;var shared=new OrquestradorCompartilhadoMasterdataR3();
        await using var c=new SingleCreateDesktopControllerR139(shared,()=>false,_=>Yes,(_,_)=>{calls++;throw new Exception("UNREACHABLE");});
        Assert.False(c.CanValidate("20000014"));Assert.False(c.Ready);
        Assert.Equal("SINGLE_CREATE_PREREQUISITES_BLOCKED",await c.ValidateAsync("20000014"));
        Assert.Equal(SingleCreateStateR31.BLOCKED,(await c.ExecuteAsync("20000014")).State);Assert.Equal(0,calls);
    }
    sealed class Session:ISingleCreateDesktopSessionR139
    {
        public bool Approved=true,Disposed;public int Calls;
        public TaskCompletionSource Entered=new(TaskCreationOptions.RunContinuationsAsynchronously),Release=new(TaskCreationOptions.RunContinuationsAsynchronously);
        public bool Hold;
        public ProntidaoSingleCreateR122 Readiness(string bp)=>new(Approved&&!Disposed&&bp=="20000014",Approved?[]:["SYNTHETIC_EXPIRED"]);
        public async Task<SingleCreateResultR31> ExecuteAsync(Guid id,CancellationToken ct)
        {
            Calls++;Entered.TrySetResult();if(Hold)await Release.Task.WaitAsync(ct);
            return new(id,SingleCreateStateR31.CONFIRMED,"SYNTHETIC_OFFLINE_ONLY");
        }
        public ValueTask DisposeAsync(){Disposed=true;return ValueTask.CompletedTask;}
    }
    [Fact] public async Task Controller_requires_explicit_preflight_then_uses_same_shared_lock()
    {
        var session=new Session{Hold=true};SingleCreateDesktopControllerR139? c=null;
        var shared=new OrquestradorCompartilhadoMasterdataR3(singleCreateAutorizado:()=>c?.Ready==true);
        c=new(shared,()=>true,_=>Yes,(_,_)=>Task.FromResult<ISingleCreateDesktopSessionR139>(session));
        Assert.False(c.Ready);await c.ValidateAsync("20000014");Assert.True(c.Ready);
        var first=c.ExecuteAsync("20000014");await session.Entered.Task;
        Assert.Equal("SHARED_LOCK_BUSY",(await c.ExecuteAsync("20000014")).Code);
        var automatic=await shared.ExecutarAsync(OrigemCicloMasterdataR3.Automatica);
        Assert.Equal(SituacaoCicloMasterdataR3.Ocupado,automatic.Situacao);
        session.Release.SetResult();await first;Assert.Equal(1,session.Calls);await c.DisposeAsync();Assert.True(session.Disposed);
    }
    [Fact] public async Task Revoked_or_expired_session_blocks_execute()
    {
        var session=new Session();
        var shared=new OrquestradorCompartilhadoMasterdataR3(execucaoDeNegocioExplicitamenteAutorizada:true);
        await using var c=new SingleCreateDesktopControllerR139(shared,()=>true,_=>Yes,(_,_)=>Task.FromResult<ISingleCreateDesktopSessionR139>(session));
        await c.ValidateAsync("20000014");session.Approved=false;
        Assert.Equal(SingleCreateStateR31.BLOCKED,(await c.ExecuteAsync("20000014")).State);Assert.Equal(0,session.Calls);
    }
    [Fact] public async Task Current_prerequisites_revocation_invalidates_cached_readiness()
    {
        var allowed=true;var session=new Session();
        var shared=new OrquestradorCompartilhadoMasterdataR3(execucaoDeNegocioExplicitamenteAutorizada:true);
        await using var c=new SingleCreateDesktopControllerR139(shared,()=>true,
            _=>new(allowed,allowed?[]:["SYNTHETIC_REVOKED"]),(_,_)=>Task.FromResult<ISingleCreateDesktopSessionR139>(session));
        await c.ValidateAsync("20000014");Assert.True(c.Ready);
        allowed=false;Assert.False(c.Ready);
        Assert.Equal(SingleCreateStateR31.BLOCKED,(await c.ExecuteAsync("20000014")).State);Assert.Equal(0,session.Calls);
    }
    static IConfiguration Config(string enabled="true",string role="synthetic_app")=>new ConfigurationBuilder().AddInMemoryCollection(
        new Dictionary<string,string?>{["Enabled"]=enabled,["Role"]=role}).Build();
    [Fact] public void Real_profile_lease_reloads_revocation_identity_and_read_failure()
    {
        IConfiguration current=Config();
        var lease=new SingleCreateProfileLeaseR139(current,()=>current,c=>c["Enabled"]=="true");
        Assert.True(lease.IsValid);current=Config("false");Assert.False(lease.IsValid);
        current=Config(role:"OTHER_IDENTITY");Assert.False(lease.IsValid);
        var missing=new SingleCreateProfileLeaseR139(Config(),()=>throw new IOException("SYNTHETIC_FILE_UNAVAILABLE"),_=>true);
        Assert.False(missing.IsValid);
    }
    [Fact] public async Task Profile_revoked_after_prepared_commit_means_zero_writer_and_no_retry()
    {
        IConfiguration current=Config();var lease=new SingleCreateProfileLeaseR139(current,()=>current,c=>c["Enabled"]=="true");
        await using var db=new TransactionBarrierTests.MemorySource {AfterCommit=()=>current=Config("false")};
        var g=new TransactionBarrierTests.Gateway(db);
        var result=await TransactionBarrierTests.Use(g,TransactionBarrierTests.Journal(db),()=>lease.IsValid)
            .ExecuteAsync(TransactionBarrierTests.Request());
        Assert.Equal(SingleCreateStateR31.INDETERMINATE,result.State);Assert.Equal(1,db.Commits);Assert.Equal(0,g.Writes);
    }
    [Fact] public void Indeterminate_status_survives_generic_refresh_and_exposes_only_attempt_and_codes()
    {
        var status=new SingleCreateUiStatusR139();var id=Guid.NewGuid();
        status.Record(new(id,SingleCreateStateR31.INDETERMINATE,"CREATE_PREPARE_OUTCOME_UNKNOWN"));
        Assert.Contains(id.ToString(),status.Display("GENERIC_REFRESH"));
        Assert.Contains("RECONCILIACAO OBRIGATORIA",status.Display("ANOTHER_REFRESH"));
        Assert.Contains("SEM RETRY AUTOMATICO",status.Text);
        status.Record(new(id,SingleCreateStateR31.BLOCKED,"synthetic private text not a valid code"));
        Assert.DoesNotContain("synthetic private",status.Text);
    }
    [Fact] public async Task Physical_preflight_failure_has_no_session_or_fallback_writer()
    {
        var calls=0;var shared=new OrquestradorCompartilhadoMasterdataR3();
        await using var c=new SingleCreateDesktopControllerR139(shared,()=>true,_=>Yes,(_,_)=>{calls++;throw new InvalidOperationException("SYNTHETIC_MISSING_JOURNAL");});
        Assert.Equal("SINGLE_CREATE_PREFLIGHT_FAILED",await c.ValidateAsync("20000014"));Assert.False(c.Ready);
        Assert.Equal(SingleCreateStateR31.BLOCKED,(await c.ExecuteAsync("20000014")).State);Assert.Equal(1,calls);
    }
    [Fact] public async Task Unitary_mode_cannot_start_automatic_desktop_loop()
    {
        var calls=0;
        var lifecycle=new CarrierDesktopLifecycle(_=>{calls++;throw new Exception("NO_FACTORY");},TimeProvider.System,
            singleCreateFactory:s=>new(s,()=>true,_=>Yes,(_,_)=>throw new Exception("NO_AUTO_PREFLIGHT")));
        lifecycle.Start();Assert.True(lifecycle.Completion.IsCompleted);Assert.Equal(0,calls);Assert.False(lifecycle.Snapshot.Active);
        await lifecycle.StopAsync();
    }
    [Fact] public void Unitary_mode_blocks_alternate_host_registration_before_worker_creation()
    {
        var c=new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string,string?>{
            ["FUGATES_CARRIER_SYNC_ENABLED"]="true",["Carrier:SingleCreate:Enabled"]="true"}).Build();
        Assert.Throws<InvalidOperationException>(()=>FugaTES.HostIntegracao.CarrierSyncComposition.ConfigurarServicos(new ServiceCollection(),c));
    }
    [Fact] public async Task Unitary_authorization_does_not_authorize_automatic_pipeline()
    {
        var calls=0;
        var action=new AcaoCategoriaDelegadaMasterdataR3(CategoriaMasterdataR3.Transportadoras,true,true,_=>{calls++;throw new Exception("NO_AUTO");});
        var shared=new OrquestradorCompartilhadoMasterdataR3([action],singleCreateAutorizado:()=>true);
        var result=await shared.ExecutarAsync(OrigemCicloMasterdataR3.Automatica);
        Assert.Equal(SituacaoCicloMasterdataR3.Bloqueado,result.Situacao);Assert.Equal(0,calls);
    }
    sealed class Inner:HttpMessageHandler
    {
        public int Calls;
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage m,CancellationToken ct){Calls++;return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK));}
    }
    [Theory]
    [InlineData("POST","/api/v0/Guardian/Transportadora",false)]
    [InlineData("PUT","/api/v0/Guardian/Transportadora",true)]
    [InlineData("GET","/api/v0/Guardian/Transportadora/OTHER",true)]
    public async Task Http_guard_blocks_unapproved_business_routes_without_external_http(string method,string path,bool gate)
    {
        var inner=new Inner();var origin=new Uri("https://synthetic.example.invalid");
        using var http=new HttpClient(new SingleCreateHttpGuardR139(origin,origin,()=>gate,inner));
        await Assert.ThrowsAnyAsync<Exception>(()=>http.SendAsync(new HttpRequestMessage(new HttpMethod(method),new Uri(origin,path))));
        Assert.Equal(0,inner.Calls);
    }
}
