using System.Collections;
using System.Collections.Concurrent;
using System.Diagnostics.CodeAnalysis;
using System.Data;
using System.Data.Common;
using FugaTES.Aplicacao.Transportadoras;
using FugaTES.Aplicacao.Transportadoras.SingleCreateR31;
using FugaTES.Persistencia.Transportadoras;
using Npgsql;

namespace FugaTES.SingleCreate.R139.Tests;

public class TransactionBarrierTests
{
    internal static readonly DateTimeOffset Now = new(2026,10,18,12,0,0,TimeSpan.Zero);
    internal sealed class Clock : TimeProvider { public override DateTimeOffset GetUtcNow()=>Now; }
    internal static SingleCreateRequestR31 Request() => new(Guid.NewGuid(),"20000014",
        new("20000014","SYNTHETIC_SCOPE",true,"SYNTHETIC_APPROVAL"),
        new("20000014","SYNTHETIC_NAME","SYNTHETIC_LEGAL"),Now.AddYears(-1),Now.AddYears(1),Now,
        new("20000014","20000014","SYNTHETIC_SCOPE","SYNTHETIC_EXECUTION_APPROVAL",Now.AddHours(1),true,true,true,true,true,true,true));
    internal sealed class Gateway(MemorySource db) : IGuardianCarrierManualReadOnly,IGuardianCarrierGateway
    {
        public int Writes;
        public Task<CarrierManualGuardian> ConsultarCodigoAsync(CarrierManualIdentity i,CancellationToken ct)
            =>Task.FromResult(new CarrierManualGuardian(CarrierLookupState.Absent,null,new Dictionary<string,string?>(),true));
        public Task<CarrierWriteResult> GravarAsync(CarrierWriteAttempt a,CancellationToken ct)
        {
            Assert.Contains("COMMIT_CONFIRMED",db.Events);
            db.Events.Add("WRITER");Interlocked.Increment(ref Writes);
            return Task.FromResult(new CarrierWriteResult(true,false,a.GuardianCode){HttpStatusCode=200});
        }
        public Task<CarrierLookup> ConsultarAsync(string bp,CancellationToken ct)=>throw new InvalidOperationException("NO_UNSCOPED_READ");
        public Task<CarrierLookup> LerConfirmacaoAsync(string code,CancellationToken ct)=>throw new InvalidOperationException("NO_POST_GET");
    }
    internal static SingleCreateJournalPostgreSqlR31 Journal(MemorySource db)
    {
        // ADO.NET seam exercises the real journal, never a fake implementation of ISingleCreateJournalR31.
        var ctor=typeof(SingleCreateJournalPostgreSqlR31).GetConstructor([typeof(DbDataSource),typeof(TimeProvider)]);
        Assert.NotNull(ctor);
        return (SingleCreateJournalPostgreSqlR31)ctor.Invoke([db,new Clock()]);
    }
    internal static GuardianSingleCreateUseCaseR31 Use(Gateway g,ISingleCreateJournalR31? j,Func<bool>? gate=null)
        =>new(g,g,j,gate??(()=>true),_=>true,clock:new Clock());

    [Fact] public async Task Commit_confirmed_precedes_writer_and_uses_own_transaction()
    {
        await using var db=new MemorySource();var g=new Gateway(db);
        var r=await Use(g,Journal(db)).ExecuteAsync(Request());
        Assert.Equal(SingleCreateStateR31.CONFIRMED,r.State);
        Assert.Equal(1,g.Writes);Assert.Equal(1,db.Commits);Assert.True(db.CommandWasEnlisted);
        Assert.True(db.Events.IndexOf("COMMIT_CONFIRMED")<db.Events.IndexOf("WRITER"));
    }
    [Fact] public async Task Writer_waits_for_commit_acknowledgement()
    {
        await using var db=new MemorySource {HoldCommit=true};var g=new Gateway(db);
        var task=Use(g,Journal(db)).ExecuteAsync(Request());
        await db.CommitEntered.Task.WaitAsync(TimeSpan.FromSeconds(5));Assert.Equal(0,g.Writes);Assert.False(task.IsCompleted);
        db.ReleaseCommit.SetResult();Assert.Equal(SingleCreateStateR31.CONFIRMED,(await task).State);
    }
    [Theory]
    [InlineData("INSERT")]
    [InlineData("COMMIT_EXCEPTION")]
    [InlineData("COMMIT_INDETERMINATE")]
    [InlineData("COMMIT_CANCELLED")]
    public async Task Prepare_failure_never_calls_writer_or_retries(string failure)
    {
        await using var db=new MemorySource {Failure=failure};var g=new Gateway(db);
        var r=await Use(g,Journal(db)).ExecuteAsync(Request());
        Assert.Equal(SingleCreateStateR31.INDETERMINATE,r.State);Assert.Equal(0,g.Writes);Assert.Equal(1,db.Inserts);
        Assert.Contains("DISPOSE_CONNECTION",db.Events);
    }
    [Fact] public async Task Refused_reservation_rolls_back_and_does_not_post()
    {
        await using var db=new MemorySource {Refuse=true};var g=new Gateway(db);
        Assert.Equal(SingleCreateStateR31.BLOCKED,(await Use(g,Journal(db)).ExecuteAsync(Request())).State);
        Assert.Equal(0,g.Writes);Assert.Equal(0,db.Commits);Assert.Contains("ROLLBACK",db.Events);
    }
    [Fact] public async Task Existing_prepared_identity_has_no_replay()
    {
        await using var db=new MemorySource();var g=new Gateway(db);var j=Journal(db);var r=Request();
        Assert.True(await j.TryPrepareAsync(r.AttemptId,r.BusinessPartner,"20000014",new string('a',64),default));
        Assert.Equal(SingleCreateStateR31.BLOCKED,(await Use(g,j).ExecuteAsync(r with{AttemptId=Guid.NewGuid()})).State);
        Assert.Equal(0,g.Writes);
    }
    [Fact] public async Task Concurrent_same_identity_has_at_most_one_eligible_attempt()
    {
        await using var db=new MemorySource();var g=new Gateway(db);var j=Journal(db);
        var results=await Task.WhenAll(Enumerable.Range(0,8).Select(_=>Task.Run(()=>Use(g,j).ExecuteAsync(Request()))));
        Assert.Single(results,r=>r.State==SingleCreateStateR31.CONFIRMED);Assert.Equal(1,g.Writes);
    }
    [Fact] public async Task Missing_journal_blocks_before_any_reservation_or_writer()
    {
        await using var db=new MemorySource();var g=new Gateway(db);
        Assert.Equal(SingleCreateStateR31.BLOCKED,(await Use(g,null).ExecuteAsync(Request())).State);
        Assert.Empty(db.Events);Assert.Equal(0,g.Writes);
    }
    [Fact] public async Task Expired_authorization_blocks_without_database_access()
    {
        await using var db=new MemorySource();var g=new Gateway(db);var r=Request();
        r=r with{Approval=r.Approval! with{UntilUtc=Now.AddSeconds(-1)}};
        Assert.Equal(SingleCreateStateR31.BLOCKED,(await Use(g,Journal(db)).ExecuteAsync(r)).State);
        Assert.Empty(db.Events);Assert.Equal(0,g.Writes);
    }
    [Fact] public async Task Default_write_gate_stays_off()
    {
        await using var db=new MemorySource();var g=new Gateway(db);
        var use=new GuardianSingleCreateUseCaseR31(g,g,Journal(db),clock:new Clock());
        Assert.Equal("SINGLE_CREATE_WRITE_GATE_OFF",(await use.ExecuteAsync(Request())).Code);Assert.Empty(db.Events);
    }

    // In-memory ADO.NET doubles. These prove sequencing, NOT PostgreSQL ACID/constraints.
    internal sealed class MemorySource : DbDataSource
    {
        internal sealed class EventLog:ConcurrentQueue<string>{public void Add(string e)=>Enqueue(e);public int IndexOf(string e)=>Array.IndexOf(ToArray(),e);}
        internal readonly EventLog Events=new();
        readonly HashSet<string> reserved=[];readonly object sync=new();
        internal string? Failure;internal bool Refuse,HoldCommit,CommandWasEnlisted;
        internal Action? AfterCommit;
        internal int Inserts,Commits;
        internal TaskCompletionSource CommitEntered=new(TaskCreationOptions.RunContinuationsAsynchronously);
        internal TaskCompletionSource ReleaseCommit=new(TaskCreationOptions.RunContinuationsAsynchronously);
        public override string ConnectionString=>"SYNTHETIC_MEMORY_ONLY";
        protected override DbConnection CreateDbConnection()=>new Connection(this);
        internal sealed class Connection(MemorySource db):DbConnection
        {
            ConnectionState state;internal string? ReservedKey;
            [AllowNull] public override string ConnectionString{get;set;}="";
            public override string Database=>"SYNTHETIC";public override string DataSource=>"MEMORY";public override string ServerVersion=>"OFFLINE";public override ConnectionState State=>state;
            public override void ChangeDatabase(string n)=>throw new NotSupportedException();
            public override void Open(){state=ConnectionState.Open;db.Events.Add("OPEN");}
            public override Task OpenAsync(CancellationToken ct){ct.ThrowIfCancellationRequested();Open();return Task.CompletedTask;}
            public override void Close()=>state=ConnectionState.Closed;
            protected override DbTransaction BeginDbTransaction(IsolationLevel level){db.Events.Add("BEGIN");return new Transaction(db,this,level);}
            protected override DbCommand CreateDbCommand()=>new Command(db,this);
            protected override void Dispose(bool disposing){db.Events.Add("DISPOSE_CONNECTION");Close();base.Dispose(disposing);}
        }
        sealed class Transaction(MemorySource db,Connection c,IsolationLevel level):DbTransaction
        {
            bool committed;
            public override IsolationLevel IsolationLevel=>level;protected override DbConnection DbConnection=>c;
            public override void Commit()=>CommitAsync().GetAwaiter().GetResult();
            public override async Task CommitAsync(CancellationToken ct=default)
            {
                db.CommitEntered.TrySetResult();if(db.HoldCommit)await db.ReleaseCommit.Task.WaitAsync(ct);
                if(db.Failure=="COMMIT_EXCEPTION")throw new InvalidOperationException("SYNTHETIC_COMMIT_FAILURE");
                if(db.Failure=="COMMIT_INDETERMINATE"){committed=true;throw new TimeoutException("SYNTHETIC_ACK_LOST");}
                if(db.Failure=="COMMIT_CANCELLED")throw new OperationCanceledException();
                committed=true;Interlocked.Increment(ref db.Commits);db.Events.Add("COMMIT_CONFIRMED");db.AfterCommit?.Invoke();
            }
            public override void Rollback(){db.Events.Add("ROLLBACK");if(!committed&&c.ReservedKey is {} key){lock(db.sync)db.reserved.Remove(key);c.ReservedKey=null;}}
            protected override void Dispose(bool disposing){if(!committed)Rollback();base.Dispose(disposing);}
        }
        sealed class Command(MemorySource db,Connection c):DbCommand
        {
            readonly NpgsqlCommand parametersOwner=new();
            [AllowNull] public override string CommandText{get;set;}="";public override int CommandTimeout{get;set;}
            public override CommandType CommandType{get;set;}=CommandType.Text;public override bool DesignTimeVisible{get;set;}
            public override UpdateRowSource UpdatedRowSource{get;set;}
            protected override DbConnection? DbConnection{get;set;}=c;protected override DbTransaction? DbTransaction{get;set;}
            protected override DbParameterCollection DbParameterCollection=>parametersOwner.Parameters;
            protected override DbParameter CreateDbParameter()=>new NpgsqlParameter();
            public override void Cancel(){} public override void Prepare(){}
            public override object? ExecuteScalar()=>"CONFIRMED";
            protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior)=>throw new NotSupportedException();
            public override int ExecuteNonQuery()
            {
                if(!CommandText.Contains("insert into",StringComparison.OrdinalIgnoreCase))return 1;
                Interlocked.Increment(ref db.Inserts);db.Events.Add("INSERT");db.CommandWasEnlisted=DbTransaction is not null;
                if(db.Failure=="INSERT")throw new InvalidOperationException("SYNTHETIC_INSERT_FAILURE");
                var key=Convert.ToString(Parameters["bp"].Value)!;
                lock(db.sync){if(db.Refuse||!db.reserved.Add(key))return 0;c.ReservedKey=key;return 1;}
            }
            public override Task<int> ExecuteNonQueryAsync(CancellationToken ct){ct.ThrowIfCancellationRequested();return Task.FromResult(ExecuteNonQuery());}
            protected override void Dispose(bool disposing){parametersOwner.Dispose();base.Dispose(disposing);}
        }
    }
}
