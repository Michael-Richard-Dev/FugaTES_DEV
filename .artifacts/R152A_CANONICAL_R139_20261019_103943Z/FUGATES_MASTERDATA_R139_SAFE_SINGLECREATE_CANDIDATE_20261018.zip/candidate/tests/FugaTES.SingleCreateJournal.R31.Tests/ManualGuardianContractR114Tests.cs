﻿using FugaTES.HostIntegracao;
using FugaTES.WinForms.Runtime;
using FugaTES.WinForms.Transportadoras;
using Microsoft.Extensions.Configuration;
namespace FugaTES.SingleCreateJournal.R31.Tests;

// R114: separacao entre o contrato da CONSULTA MANUAL e o contrato do CICLO COMPLETO.
// A consulta manual exige apenas o que consome; o ciclo completo e CREATE/UPDATE seguem exigindo tudo.
public sealed class ManualGuardianContractR114Tests
{
    private static Dictionary<string, string?> Base() => new()
    {
        ["Carrier:Protocols:Guardian:Environment"] = "HML",
        ["Carrier:Protocols:Guardian:ProfileVerified"] = "true",
        ["Carrier:Protocols:Guardian:SignatureVerified"] = "true",
        ["Carrier:Protocols:Guardian:ApprovalReference"] = "OFFLINE_APPROVAL_REFERENCE",
        ["Carrier:Protocols:Guardian:LookupRoute"] = "/api/v0/Guardian/Transportadora/{bp}?idAssinatura=133289",
        ["Carrier:Protocols:Guardian:CodeField"] = "codigo",
        ["Carrier:Protocols:Guardian:LegalNameField"] = "razaoSocial",
        ["Carrier:Protocols:Guardian:AbsenceHttpStatus"] = "404"
    };

    private static IConfiguration Config(Action<Dictionary<string, string?>>? mutate = null)
    {
        var values = Base();
        mutate?.Invoke(values);
        return new ConfigurationBuilder().AddInMemoryCollection(values).Build();
    }

    // ---------- 3. exigir apenas os campos efetivamente consumidos ----------

    [Fact]
    public void Contrato_manual_dispensa_os_campos_do_ciclo_completo()
    {
        var config = Config();
        var manual = CarrierProtocolBinding.BuildGuardianManualContract(config);
        Assert.NotNull(manual);
        Assert.Equal("codigo", manual!.CodeField);
        Assert.Equal("razaoSocial", manual.LegalNameField);
        Assert.True(manual.Scoped404Proven);
        // Nenhum destes foi informado e ainda assim o contrato manual e valido.
        foreach (var ausente in new[]
        {
            "Carrier:Protocols:Guardian:BusinessPartnerField", "Carrier:Protocols:Guardian:NameField",
            "Carrier:Protocols:Guardian:CreateRoute", "Carrier:Protocols:Guardian:UpdateRoute",
            "Carrier:Protocols:Guardian:ReadbackRoute", "Carrier:Protocols:Guardian:RowsPath",
            "Carrier:Protocols:Guardian:WriteCodeField", "Carrier:Protocols:Guardian:ResponseCodePath"
        })
            Assert.Null(config[ausente]);
    }

    // ---------- 4. o ciclo completo continua exigindo tudo ----------

    [Fact]
    public void Ciclo_completo_continua_bloqueado_sem_os_campos_de_escrita_e_de_bp()
        => Assert.Null(CarrierProtocolBinding.BuildGuardianContract(Config()));

    [Fact]
    public void Separacao_e_visivel_no_mesmo_perfil()
    {
        var config = Config();
        // Mesmo perfil: manual comprovado, ciclo completo nao comprovado.
        Assert.NotNull(CarrierProtocolBinding.BuildGuardianManualContract(config));
        Assert.Null(CarrierProtocolBinding.BuildGuardianContract(config));
    }

    // ---------- 6. campos ausentes ou falsos continuam bloqueando ----------

    [Theory]
    [InlineData("Carrier:Protocols:Guardian:Environment", "PRD")]
    [InlineData("Carrier:Protocols:Guardian:ProfileVerified", "false")]
    [InlineData("Carrier:Protocols:Guardian:SignatureVerified", "false")]
    [InlineData("Carrier:Protocols:Guardian:ApprovalReference", "")]
    [InlineData("Carrier:Protocols:Guardian:LookupRoute", "")]
    [InlineData("Carrier:Protocols:Guardian:CodeField", "")]
    [InlineData("Carrier:Protocols:Guardian:LegalNameField", "")]
    public void Campo_ausente_ou_falso_bloqueia_o_contrato_manual(string chave, string valor)
        => Assert.Null(CarrierProtocolBinding.BuildGuardianManualContract(Config(v => v[chave] = valor)));

    [Theory]
    [InlineData("/api/v0/Guardian/Transportadora/20000014")]            // sem marcador {bp}
    [InlineData("https://externo.invalid/api/{bp}")]                     // absoluta
    [InlineData("//externo.invalid/api/{bp}")]                           // protocolo relativo
    [InlineData("/api/v0/Guardian/Transportadora/{bp}#frag")]            // fragmento
    [InlineData("\\api\\v0\\{bp}")]                                      // barra invertida
    public void Rota_de_lookup_insegura_ou_sem_marcador_bloqueia(string rota)
        => Assert.Null(CarrierProtocolBinding.BuildGuardianManualContract(
            Config(v => v["Carrier:Protocols:Guardian:LookupRoute"] = rota)));

    [Fact]
    public void Campos_de_codigo_e_razao_social_nao_podem_coincidir()
        => Assert.Null(CarrierProtocolBinding.BuildGuardianManualContract(
            Config(v => v["Carrier:Protocols:Guardian:LegalNameField"] = "codigo")));

    [Theory]
    [InlineData("200")]
    [InlineData("410")]
    [InlineData("nao-numerico")]
    public void Status_de_ausencia_diferente_de_404_bloqueia(string status)
        => Assert.Null(CarrierProtocolBinding.BuildGuardianManualContract(
            Config(v => v["Carrier:Protocols:Guardian:AbsenceHttpStatus"] = status)));

    [Fact]
    public void Ausencia_de_status_404_mantem_404_nao_comprovado()
    {
        var manual = CarrierProtocolBinding.BuildGuardianManualContract(
            Config(v => v.Remove("Carrier:Protocols:Guardian:AbsenceHttpStatus")));
        Assert.NotNull(manual);
        // Sem 404 escopado comprovado, uma ausencia vira INDETERMINATE, nunca CREATE_CANDIDATE.
        Assert.False(manual!.Scoped404Proven);
    }

    // ---------- 5. vinculo explicito da identidade Guardian permanece obrigatorio ----------

    [Fact]
    public void Contrato_manual_nao_substitui_o_vinculo_de_identidade()
    {
        // O contrato manual pode estar comprovado e ainda assim a identidade do BP nao estar vinculada.
        var config = Config(v =>
        {
            v["Carrier:ManualReadOnly:Identities:20000014:Proven"] = "true";
            v["Carrier:ManualReadOnly:Identities:20000014:Code"] = "20000014";
            v["Carrier:ManualReadOnly:Identities:20000014:GetSignatureId"] = "133289";
            // ApprovalReference ausente de proposito
        });
        Assert.NotNull(CarrierProtocolBinding.BuildGuardianManualContract(config));
        Assert.Null(CarrierManualReadOnlyProfile.Identity(config, "20000014"));
    }

    // ---------- 7. o perfil manual nao habilita sincronizacao automatica ----------

    [Theory]
    [InlineData("FUGATES_INTEGRATION_WORKER_ENABLED")]
    [InlineData("INC005_WORKER_ENABLED")]
    [InlineData("Carrier:IntegrationWorkerEnabled")]
    [InlineData("Carrier:DesktopGuardianWritesEnabled")]
    [InlineData("Carrier:Authorization:IncrementalReleased")]
    public void Flag_operacional_ligada_bloqueia_a_consulta_manual(string chave)
    {
        var values = Base();
        values["Carrier:Environment"] = "HML";
        values["Carrier:DesktopProfileApproved"] = "true";
        values["Carrier:ApprovalReference"] = "OFFLINE_REF";
        values["Carrier:ManualReadOnly:Approved"] = "true";
        values["Carrier:ManualReadOnly:ApprovalReference"] = "OFFLINE_REF";
        foreach (var f in new[]
        {
            "FUGATES_INTEGRATION_WORKER_ENABLED", "INC005_WORKER_ENABLED", "Carrier:IntegrationWorkerEnabled",
            "Carrier:DesktopGuardianWritesEnabled", "Carrier:Authorization:IncrementalReleased"
        }) values[f] = "false";
        values[chave] = "true";
        var config = new ConfigurationBuilder().AddInMemoryCollection(values).Build();
        var erro = Assert.Throws<DesktopStartupException>(() =>
            CarrierManualReadOnlyProfile.Validate(config, "20000014", "S-1-5-21-0-0-0-1000", DateTimeOffset.UtcNow));
        Assert.Equal("MANUAL_READONLY_FLAGS_NOT_PROVEN_FALSE", erro.Code);
    }
}
