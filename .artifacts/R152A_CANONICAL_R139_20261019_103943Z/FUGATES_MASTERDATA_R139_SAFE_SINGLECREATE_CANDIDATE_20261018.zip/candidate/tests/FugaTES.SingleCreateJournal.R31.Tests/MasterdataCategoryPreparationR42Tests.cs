﻿using FugaTES.WinForms.Transportadoras.MasterdataR3;
namespace FugaTES.SingleCreateJournal.R31.Tests;

// Preparacao de Emissores/Materiais (FASE B) e Motoristas/Veiculos (FASE C).
// Prova que preparar nao ativa: nenhuma categoria preparada executa ciclo nem admite CREATE-only.
public sealed class MasterdataCategoryPreparationR42Tests
{
    private static readonly DateTimeOffset Now = new(2026, 10, 16, 12, 0, 0, TimeSpan.Zero);
    private sealed class Clock : TimeProvider { public override DateTimeOffset GetUtcNow() => Now; }

    [Fact]
    public void Fase_b_cobre_emissores_e_materiais_e_fase_c_motoristas_e_veiculos()
    {
        Assert.Equal([CategoriaMasterdataR3.Emissores, CategoriaMasterdataR3.Materiais],
            MasterdataCategoryPreparationR42.FaseB.Select(p => p.Categoria));
        Assert.Equal([CategoriaMasterdataR3.Motoristas, CategoriaMasterdataR3.Veiculos],
            MasterdataCategoryPreparationR42.FaseC.Select(p => p.Categoria));
    }

    [Fact]
    public void Nenhuma_categoria_preparada_tem_contrato_ou_checkpoint_comprovado()
        => Assert.All(MasterdataCategoryPreparationR42.Todas, preparo =>
        {
            Assert.False(preparo.ContratoHomologado);
            Assert.False(preparo.CheckpointDuravelDisponivel);
        });

    [Fact]
    public void Motivo_de_bloqueio_e_especifico_por_categoria()
    {
        Assert.Equal("EMISSOR_RECONCILIATION_CONTRACT_NOT_PROVEN", MasterdataCategoryPreparationR42.Emissores.Motivo);
        Assert.Equal("MATERIAL_RECONCILIATION_CONTRACT_NOT_PROVEN", MasterdataCategoryPreparationR42.Materiais.Motivo);
        Assert.Equal("MOTORISTA_SAP_SOURCE_NOT_PROVEN", MasterdataCategoryPreparationR42.Motoristas.Motivo);
        Assert.Equal("VEICULO_SOURCE_AND_API_NOT_PROVEN", MasterdataCategoryPreparationR42.Veiculos.Motivo);
        Assert.Equal(4, MasterdataCategoryPreparationR42.Todas.Select(p => p.Motivo).Distinct().Count());
    }

    [Fact]
    public async Task Acao_preparada_devolve_bloqueado_sem_processar_nada()
    {
        foreach (var preparo in MasterdataCategoryPreparationR42.Todas)
        {
            var resultado = await preparo.ParaAcao().ExecutarIncrementalAsync(default);
            Assert.Equal(EstadoMasterdataR3.Bloqueado, resultado.Estado);
            Assert.Equal(0, resultado.Processados);
            Assert.Equal(0, resultado.Sincronizados);
            Assert.False(resultado.CheckpointDuravelmenteConfirmado);
            Assert.Null(resultado.ReferenciaCheckpoint);
        }
    }

    [Fact]
    public async Task Registrar_as_categorias_preparadas_nao_executa_ciclo_algum()
    {
        // Runtime autorizado e escrita de negocio liberada de proposito: mesmo assim o orquestrador
        // pula fail-closed, porque contrato e checkpoint nao estao comprovados.
        var orquestrador = new OrquestradorCompartilhadoMasterdataR3(
            MasterdataCategoryPreparationR42.Acoes(), tempo: new Clock(), runtimeAutorizado: () => true);
        var execucao = await orquestrador.ExecutarAsync(OrigemCicloMasterdataR3.Automatica, default);
        Assert.Equal(SituacaoCicloMasterdataR3.Bloqueado, execucao.Situacao);
        Assert.Equal(0, execucao.CategoriasExecutadas);
        Assert.Equal(Enum.GetValues<CategoriaMasterdataR3>().Length, execucao.CategoriasBloqueadas);
    }

    [Fact]
    public void Transportadoras_e_contratos_nao_sao_tocadas_pela_preparacao()
    {
        var preparadas = MasterdataCategoryPreparationR42.Todas.Select(p => p.Categoria).ToArray();
        Assert.DoesNotContain(CategoriaMasterdataR3.Transportadoras, preparadas);
        Assert.DoesNotContain(CategoriaMasterdataR3.Contratos, preparadas);
    }
}
