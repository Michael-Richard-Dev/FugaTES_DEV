﻿using FugaTES.Aplicacao.Transportadoras;
using FugaTES.Aplicacao.Transportadoras.SingleCreateR31;
using FugaTES.Persistencia.Transportadoras;
using FugaTES.Persistencia.Transportadoras.Fakes;
namespace FugaTES.Testes;

// Journal durable do CREATE unitario (R31). Tudo offline: nenhum servidor PostgreSQL, nenhum
// POST Guardian e nenhuma execucao de migration. O duplo em memoria compartilha a politica do
// adapter, de modo que a semantica provada aqui e a mesma que roda em HML.
public sealed class SingleCreateJournalR31Tests
{
    private const string Bp = "14100050";
    private const string Code = "OFFLINE_NEW_CODE";
    private static readonly string Hash = new('a', 64);
    private static readonly DateTimeOffset Now = new(2026, 10, 16, 12, 0, 0, TimeSpan.Zero);
    private sealed class Clock : TimeProvider { public override DateTimeOffset GetUtcNow() => Now; }

    // ---------- politica pura ----------

    [Fact]
    public void Entrada_invalida_e_rejeitada_antes_de_qualquer_acesso()
    {
        Assert.Throws<ArgumentException>(() => SingleCreateJournalPolicyR31.ValidateEntry(Guid.Empty, Bp, Code, Hash));
        Assert.Throws<ArgumentException>(() => SingleCreateJournalPolicyR31.ValidateEntry(Guid.NewGuid(), "", Code, Hash));
        Assert.Throws<ArgumentException>(() => SingleCreateJournalPolicyR31.ValidateEntry(Guid.NewGuid(), Bp, Code, "nao-e-hash"));
        Assert.Throws<ArgumentException>(() => SingleCreateJournalPolicyR31.ValidateEntry(Guid.NewGuid(), Bp, new string('C', 21), Hash));
    }

    [Fact]
    public void Reserva_de_uma_linha_reserva_e_zero_linha_rejeita()
    {
        Assert.Equal(SingleCreatePrepareOutcomeR31.Reserved, SingleCreateJournalPolicyR31.ClassifyInsert(1));
        Assert.Equal(SingleCreatePrepareOutcomeR31.Rejected, SingleCreateJournalPolicyR31.ClassifyInsert(0));
        Assert.Equal(SingleCreatePrepareOutcomeR31.Unknown, SingleCreateJournalPolicyR31.ClassifyInsert(2));
    }

    [Theory]
    [InlineData("23505", SingleCreatePrepareOutcomeR31.Rejected)]
    [InlineData("23P01", SingleCreatePrepareOutcomeR31.Rejected)]
    [InlineData("40001", SingleCreatePrepareOutcomeR31.Unknown)]
    [InlineData("40P01", SingleCreatePrepareOutcomeR31.Unknown)]
    [InlineData("08006", SingleCreatePrepareOutcomeR31.Unknown)]
    [InlineData(null, SingleCreatePrepareOutcomeR31.Unknown)]
    public void Falha_de_unicidade_e_rejeicao_definida_e_o_resto_permanece_indeterminado(string? sqlState, SingleCreatePrepareOutcomeR31 esperado)
        => Assert.Equal(esperado, SingleCreateJournalPolicyR31.ClassifyFailure(sqlState));

    [Fact]
    public void Confirmacao_exige_linha_afetada_ou_mesmo_attempt_ja_confirmado()
    {
        Assert.True(SingleCreateJournalPolicyR31.ConfirmSatisfied(1, SingleCreateJournalPolicyR31.ConfirmedStatus));
        Assert.True(SingleCreateJournalPolicyR31.ConfirmSatisfied(0, SingleCreateJournalPolicyR31.ConfirmedStatus));
        Assert.False(SingleCreateJournalPolicyR31.ConfirmSatisfied(0, SingleCreateJournalPolicyR31.PreparedStatus));
        Assert.False(SingleCreateJournalPolicyR31.ConfirmSatisfied(0, null));
    }

    // ---------- SQL do adapter ----------

    [Fact]
    public void Reserva_e_atomica_em_uma_sentenca_e_bloqueia_pendencia_e_replay()
    {
        var sql = SingleCreateJournalPostgreSqlR31.PrepareSql;
        Assert.Contains("not exists", sql, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("bp=@bp or guardian_code=@code or attempt_id=@attempt", sql, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("'PREPARED'", sql);
        // Uma unica sentenca: nenhum ponto e virgula interno separando comandos.
        Assert.DoesNotContain(";", sql);
    }

    [Fact]
    public void Confirmacao_so_promove_linha_preparada_do_proprio_attempt()
    {
        var sql = SingleCreateJournalPostgreSqlR31.ConfirmSql;
        Assert.Contains("attempt_id=@attempt", sql, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("status='PREPARED'", sql);
        Assert.Contains("'CONFIRMED'", sql);
    }

    [Fact]
    public void Journal_nunca_apaga_linha()
    {
        foreach (var sql in new[] { SingleCreateJournalPostgreSqlR31.PrepareSql, SingleCreateJournalPostgreSqlR31.ConfirmSql, SingleCreateJournalPostgreSqlR31.ObserveSql })
        {
            Assert.DoesNotContain("delete", sql, StringComparison.OrdinalIgnoreCase);
            Assert.DoesNotContain("truncate", sql, StringComparison.OrdinalIgnoreCase);
        }
    }

    [Fact]
    public async Task Banco_inacessivel_nunca_reserva_e_nunca_e_silencioso()
    {
        await using var source = Npgsql.NpgsqlDataSource.Create("Host=127.0.0.1;Port=1;Username=local_test;Database=local_test;Timeout=1");
        var journal = new SingleCreateJournalPostgreSqlR31(source, new Clock());
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        // Falha de infraestrutura propaga: o caso de uso a traduz em CREATE_PREPARE_OUTCOME_UNKNOWN,
        // jamais em "pode enviar".
        await Assert.ThrowsAnyAsync<Exception>(() => journal.TryPrepareAsync(Guid.NewGuid(), Bp, Code, Hash, timeout.Token));
        await Assert.ThrowsAnyAsync<Exception>(() => journal.ConfirmAsync(Guid.NewGuid(), timeout.Token));
    }

    [Fact]
    public async Task Entrada_invalida_nao_chega_ao_banco()
    {
        await using var source = Npgsql.NpgsqlDataSource.Create("Host=127.0.0.1;Port=1;Username=local_test;Database=local_test;Timeout=1");
        var journal = new SingleCreateJournalPostgreSqlR31(source, new Clock());
        await Assert.ThrowsAsync<ArgumentException>(() => journal.TryPrepareAsync(Guid.Empty, Bp, Code, Hash, default));
        await Assert.ThrowsAsync<ArgumentException>(() => journal.ConfirmAsync(Guid.Empty, default));
    }

    // ---------- semantica compartilhada (duplo em memoria) ----------

    [Fact]
    public async Task Primeira_reserva_vence_e_replay_do_mesmo_bp_e_rejeitado()
    {
        var journal = new SingleCreateJournalMemoryFakeR31(new Clock());
        Assert.True(await journal.TryPrepareAsync(Guid.NewGuid(), Bp, Code, Hash, default));
        Assert.False(await journal.TryPrepareAsync(Guid.NewGuid(), Bp, "OUTRO_CODIGO", Hash, default));
        Assert.Single(journal.Entries);
    }

    [Fact]
    public async Task Replay_do_mesmo_codigo_guardian_em_outro_bp_e_rejeitado()
    {
        var journal = new SingleCreateJournalMemoryFakeR31(new Clock());
        Assert.True(await journal.TryPrepareAsync(Guid.NewGuid(), Bp, Code, Hash, default));
        Assert.False(await journal.TryPrepareAsync(Guid.NewGuid(), "14100051", Code, Hash, default));
    }

    [Fact]
    public async Task Repreparar_o_mesmo_attempt_nao_libera_segundo_envio()
    {
        var journal = new SingleCreateJournalMemoryFakeR31(new Clock());
        var attempt = Guid.NewGuid();
        Assert.True(await journal.TryPrepareAsync(attempt, Bp, Code, Hash, default));
        Assert.False(await journal.TryPrepareAsync(attempt, Bp, Code, Hash, default));
    }

    [Fact]
    public async Task Concorrencia_reserva_exatamente_uma_tentativa()
    {
        var journal = new SingleCreateJournalMemoryFakeR31(new Clock());
        var corridas = Enumerable.Range(0, 64)
            .Select(_ => Task.Run(() => journal.TryPrepareAsync(Guid.NewGuid(), Bp, Code, Hash, default)))
            .ToArray();
        var resultados = await Task.WhenAll(corridas);
        Assert.Equal(1, resultados.Count(reservado => reservado));
        Assert.Single(journal.Entries);
    }

    [Fact]
    public async Task Confirmacao_e_idempotente_e_desconhecida_falha_fechada()
    {
        var journal = new SingleCreateJournalMemoryFakeR31(new Clock());
        var attempt = Guid.NewGuid();
        Assert.True(await journal.TryPrepareAsync(attempt, Bp, Code, Hash, default));
        await journal.ConfirmAsync(attempt, default);
        await journal.ConfirmAsync(attempt, default);
        var registro = Assert.Single(journal.Entries);
        Assert.Equal(SingleCreateJournalPolicyR31.ConfirmedStatus, registro.Status);
        Assert.Equal(Now, registro.ConfirmedUtc);
        await Assert.ThrowsAsync<InvalidOperationException>(() => journal.ConfirmAsync(Guid.NewGuid(), default));
    }

    [Fact]
    public async Task Bp_confirmado_nunca_admite_segundo_create()
    {
        var journal = new SingleCreateJournalMemoryFakeR31(new Clock());
        var attempt = Guid.NewGuid();
        Assert.True(await journal.TryPrepareAsync(attempt, Bp, Code, Hash, default));
        await journal.ConfirmAsync(attempt, default);
        // Duplicidade: o journal e a unica barreira depois do HTTP 200 e ela permanece fechada.
        Assert.False(await journal.TryPrepareAsync(Guid.NewGuid(), Bp, Code, Hash, default));
    }

    // ---------- cadeia completa do caso de uso ----------

    private sealed class Gateway : IGuardianCarrierManualReadOnly, IGuardianCarrierGateway
    {
        public int Writes;
        public Task<CarrierManualGuardian> ConsultarCodigoAsync(CarrierManualIdentity i, CancellationToken ct)
            => Task.FromResult(new CarrierManualGuardian(CarrierLookupState.Absent, null, new Dictionary<string, string?>(), true));
        public Task<CarrierLookup> ConsultarAsync(string bp, CancellationToken ct) => throw new Exception("NO_BP_LOOKUP");
        public Task<CarrierLookup> LerConfirmacaoAsync(string code, CancellationToken ct) => throw new Exception("NO_UNSCOPED_READBACK");
        public Task<CarrierWriteResult> GravarAsync(CarrierWriteAttempt a, CancellationToken ct)
        {
            Writes++;
            return Task.FromResult(new CarrierWriteResult(true, false, a.GuardianCode) { HttpStatusCode = 200 });
        }
    }

    private static SingleCreateRequestR31 Pedido() => new(Guid.NewGuid(), Bp,
        new(Code, "OFFLINE_GET_SCOPE", true, "OFFLINE_ID_PROOF"),
        new(Bp, "OFFLINE_NAME", "OFFLINE_LEGAL_NAME"), Now.AddDays(-2), Now.AddDays(2), Now,
        new(Bp, Code, "OFFLINE_GET_SCOPE", "OFFLINE_SPECIFIC_APPROVAL", Now.AddHours(1), true, true, true, true, true, true, true));

    [Fact]
    public async Task Create_confirma_e_o_replay_seguinte_bloqueia_sem_novo_envio()
    {
        var gateway = new Gateway();
        var journal = new SingleCreateJournalMemoryFakeR31(new Clock());
        var caso = new GuardianSingleCreateUseCaseR31(gateway, gateway, journal, () => true, _ => true, clock: new Clock());

        var primeiro = await caso.ExecuteAsync(Pedido());
        Assert.Equal(SingleCreateStateR31.CONFIRMED, primeiro.State);
        Assert.Equal("CREATE_HTTP200_CODE_CONFIRMED", primeiro.Code);
        Assert.Equal(1, gateway.Writes);

        var segundo = await caso.ExecuteAsync(Pedido());
        Assert.Equal(SingleCreateStateR31.BLOCKED, segundo.State);
        Assert.Equal("PENDING_OR_REPLAY_RECONCILIATION_REQUIRED", segundo.Code);
        // Nenhum POST adicional: a duplicidade e barrada antes do despacho.
        Assert.Equal(1, gateway.Writes);
    }

    [Fact]
    public async Task Sem_journal_o_caso_de_uso_permanece_bloqueado()
    {
        var gateway = new Gateway();
        var caso = new GuardianSingleCreateUseCaseR31(gateway, gateway, null, () => true, _ => true, clock: new Clock());
        var resultado = await caso.ExecuteAsync(Pedido());
        Assert.Equal(SingleCreateStateR31.BLOCKED, resultado.State);
        Assert.Equal("POSTGRESQL_RUNTIME_NOT_ATTESTED", resultado.Code);
        Assert.Equal(0, gateway.Writes);
    }

    [Fact]
    public async Task Journal_indisponivel_produz_indeterminado_sem_envio()
    {
        var gateway = new Gateway();
        await using var source = Npgsql.NpgsqlDataSource.Create("Host=127.0.0.1;Port=1;Username=local_test;Database=local_test;Timeout=1");
        var caso = new GuardianSingleCreateUseCaseR31(gateway, gateway, new SingleCreateJournalPostgreSqlR31(source, new Clock()), () => true, _ => true, clock: new Clock());
        var resultado = await caso.ExecuteAsync(Pedido());
        Assert.Equal(SingleCreateStateR31.INDETERMINATE, resultado.State);
        Assert.Equal("CREATE_PREPARE_OUTCOME_UNKNOWN", resultado.Code);
        Assert.Equal(0, gateway.Writes);
    }
}
