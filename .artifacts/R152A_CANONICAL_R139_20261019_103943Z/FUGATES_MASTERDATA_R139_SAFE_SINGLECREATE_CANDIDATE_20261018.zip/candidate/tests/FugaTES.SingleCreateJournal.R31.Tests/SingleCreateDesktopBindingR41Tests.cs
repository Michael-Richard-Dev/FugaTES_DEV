﻿using FugaTES.Aplicacao.Transportadoras;
using FugaTES.HostIntegracao;
using FugaTES.Integracao.SAP.BusinessPartner;
using FugaTES.Persistencia.Transportadoras;
using FugaTES.WinForms.Transportadoras.MasterdataR3;
using Microsoft.Extensions.Configuration;
namespace FugaTES.SingleCreateJournal.R31.Tests;

// Ligacao do journal durable ao CREATE unitario. Nenhum acesso real a banco, SAP ou Guardian:
// os colaboradores de rede sao passados como null para provar que a ligacao bloqueada nunca os toca.
public sealed class SingleCreateDesktopBindingR41Tests
{
    private static readonly DateTimeOffset Now = new(2026, 10, 16, 12, 0, 0, TimeSpan.Zero);
    private sealed class Clock : TimeProvider { public override DateTimeOffset GetUtcNow() => Now; }

    private sealed class SapNeverRead : ISapBpMasterReaderR20B
    {
        public Task<SapBpReadResultR20B> ReadAsync(string businessPartner, CancellationToken cancellationToken)
            => throw new InvalidOperationException("NO_SAP_READ_IN_BINDING_TEST");
    }

    private static Npgsql.NpgsqlDataSource UnreachableDatabase()
        => Npgsql.NpgsqlDataSource.Create("Host=127.0.0.1;Port=1;Username=local_test;Database=local_test;Timeout=1");

    private static IConfiguration Config(params (string Key, string Value)[] overrides)
    {
        var values = new Dictionary<string, string?>
        {
            ["Carrier:Environment"] = "HML",
            ["Carrier:SingleCreate:Enabled"] = "true",
            ["Carrier:Protocols:Guardian:Environment"] = "HML",
            ["Carrier:Protocols:Guardian:ProfileVerified"] = "true",
            ["Carrier:Protocols:Guardian:SignatureVerified"] = "true",
            ["Carrier:Protocols:Guardian:ApprovalReference"] = "OFFLINE_APPROVAL_REFERENCE",
            ["Carrier:Protocols:Guardian:LookupRoute"] = "/offline/lookup/{bp}",
            ["Carrier:Protocols:Guardian:CreateRoute"] = "/offline/create",
            ["Carrier:Protocols:Guardian:UpdateRoute"] = "/offline/update/{code}",
            ["Carrier:Protocols:Guardian:ReadbackRoute"] = "/offline/readback/{code}",
            ["Carrier:Protocols:Guardian:RowsPath"] = "$",
            ["Carrier:Protocols:Guardian:BusinessPartnerField"] = "OfflineBp",
            ["Carrier:Protocols:Guardian:CodeField"] = "OfflineCode",
            ["Carrier:Protocols:Guardian:NameField"] = "OfflineName",
            ["Carrier:Protocols:Guardian:LegalNameField"] = "OfflineLegalName",
            ["Carrier:Protocols:Guardian:WriteCodeField"] = "OfflineWriteCode",
            ["Carrier:Protocols:Guardian:WriteNameField"] = "OfflineWriteName",
            ["Carrier:Protocols:Guardian:WriteLegalNameField"] = "OfflineWriteLegalName",
            ["Carrier:Protocols:Guardian:ResponseCodePath"] = "OfflineResponseCode"
        };
        foreach (var (key, value) in overrides) values[key] = value;
        return new ConfigurationBuilder().AddInMemoryCollection(values).Build();
    }

    // Preparacao bloqueada sem nenhuma leitura SAP: a decisao nao esta aprovada.
    private static async Task<PreparedSingleCreateR41> PreparacaoBloqueadaAsync()
    {
        var prepared = await new GuardianSingleCreatePreparationR41(new SapNeverRead(), new Clock())
            .PrepareAsync(new SingleCarrierDecisionR41("20000014", "20000014", 1, "https://offline.invalid/callback"));
        Assert.False(prepared.Ready);
        return prepared;
    }

    [Fact]
    public async Task Ausencia_de_liberacao_desliga_a_ligacao_sem_tocar_banco_nem_rede()
    {
        await using var source = UnreachableDatabase();
        using var prepared = await PreparacaoBloqueadaAsync();
        var binding = await SingleCreateDesktopBindingR41.BindAsync(
            Config(("Carrier:SingleCreate:Enabled", "false")), prepared,
            reader: null!, gatewayFactory: null!, source: source, clock: new Clock());
        Assert.False(binding.Ready);
        Assert.Null(binding.UseCase);
        Assert.Equal("SINGLE_CREATE_DESKTOP_DISABLED", binding.Code);
    }

    [Fact]
    public async Task Chave_de_liberacao_ausente_tambem_desliga()
    {
        await using var source = UnreachableDatabase();
        using var prepared = await PreparacaoBloqueadaAsync();
        var binding = await SingleCreateDesktopBindingR41.BindAsync(
            Config(("Carrier:SingleCreate:Enabled", null!)), prepared,
            null!, null!, source, clock: new Clock());
        Assert.Equal("SINGLE_CREATE_DESKTOP_DISABLED", binding.Code);
    }

    [Fact]
    public async Task Ambiente_fora_de_hml_nao_liga()
    {
        await using var source = UnreachableDatabase();
        using var prepared = await PreparacaoBloqueadaAsync();
        var binding = await SingleCreateDesktopBindingR41.BindAsync(
            Config(("Carrier:Environment", "PRD")), prepared, null!, null!, source, clock: new Clock());
        Assert.False(binding.Ready);
        Assert.Equal("CARRIER_DESKTOP_HML_NOT_PROVEN", binding.Code);
    }

    [Theory]
    [InlineData("Carrier:Protocols:Guardian:ProfileVerified")]
    [InlineData("Carrier:Protocols:Guardian:SignatureVerified")]
    public async Task Perfil_ou_assinatura_nao_comprovados_nao_ligam(string chave)
    {
        await using var source = UnreachableDatabase();
        using var prepared = await PreparacaoBloqueadaAsync();
        var binding = await SingleCreateDesktopBindingR41.BindAsync(
            Config((chave, "false")), prepared, null!, null!, source, clock: new Clock());
        Assert.False(binding.Ready);
        Assert.Equal("CARRIER_DESKTOP_GUARDIAN_HML_NOT_PROVEN", binding.Code);
    }

    [Fact]
    public async Task Contrato_guardian_incompleto_nao_liga()
    {
        await using var source = UnreachableDatabase();
        using var prepared = await PreparacaoBloqueadaAsync();
        var binding = await SingleCreateDesktopBindingR41.BindAsync(
            Config(("Carrier:Protocols:Guardian:ReadbackRoute", "/offline/readback/sem-marcador")),
            prepared, null!, null!, source, clock: new Clock());
        Assert.Equal("CARRIER_DESKTOP_GUARDIAN_HML_NOT_PROVEN", binding.Code);
    }

    [Fact]
    public async Task Preparacao_bloqueada_propaga_o_proprio_codigo_antes_do_banco()
    {
        await using var source = UnreachableDatabase();
        using var prepared = await PreparacaoBloqueadaAsync();
        var binding = await SingleCreateDesktopBindingR41.BindAsync(
            Config(), prepared, null!, null!, source, clock: new Clock());
        Assert.False(binding.Ready);
        // Codigo da propria preparacao, nao um codigo generico: a causa permanece rastreavel.
        Assert.Equal(prepared.Code, binding.Code);
        Assert.Equal("R41_FUNCTIONAL_IDENTITY_NOT_APPROVED", binding.Code);
    }

    [Fact]
    public async Task Cancelamento_nao_liga()
    {
        await using var source = UnreachableDatabase();
        using var prepared = await PreparacaoBloqueadaAsync();
        using var cancelled = new CancellationTokenSource();
        await cancelled.CancelAsync();
        var binding = await SingleCreateDesktopBindingR41.BindAsync(
            Config(), prepared, null!, null!, source, clock: new Clock(), ct: cancelled.Token);
        Assert.False(binding.Ready);
        Assert.Equal("SINGLE_CREATE_CANCELLED", binding.Code);
    }

    [Fact]
    public async Task Preflight_do_journal_falha_fechado_com_banco_inacessivel()
    {
        await using var source = UnreachableDatabase();
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        await Assert.ThrowsAnyAsync<Exception>(() => SingleCreateDesktopBindingR41.JournalReadyAsync(source, timeout.Token));
    }

    [Fact]
    public void Preflight_exige_select_insert_update_e_proibe_delete_truncate()
    {
        var sql = SingleCreateDesktopBindingR41.JournalPrivilegeSql;
        Assert.Contains("to_regclass(@name) is null then false", sql);
        foreach (var privilege in new[] { "SELECT", "INSERT", "UPDATE" })
            Assert.Contains("has_table_privilege(current_user,@name,'" + privilege + "')", sql);
        Assert.Contains("not has_table_privilege(current_user,@name,'DELETE,TRUNCATE')", sql);
    }

    [Fact]
    public void Preflight_do_journal_nao_toca_as_tabelas_compartilhadas_carrier_sync()
    {
        Assert.Equal(SingleCreateJournalPostgreSqlR31.Table, SingleCreateDesktopBindingR41.JournalTable);
        Assert.DoesNotContain("carrier_sync_", SingleCreateDesktopBindingR41.JournalTable);
    }

    // ---------- autorizacao de escrita (equivalencia preservada apos mover o transporte) ----------

    private static CarrierWriteAttempt Tentativa(string acao = "CREATE", string bp = "20000014", string? codigo = "20000014")
        => new(Guid.NewGuid(), bp, codigo, acao, new(bp, "OFFLINE_NAME", "OFFLINE_LEGAL_NAME"));

    [Fact]
    public async Task Autorizacao_nega_com_gate_desligado_ou_ausente()
    {
        using var prepared = await PreparacaoBloqueadaAsync();
        Assert.False(SingleCreateDesktopBindingR41.Autorizacao(prepared, () => false)(Tentativa()));
        Assert.False(SingleCreateDesktopBindingR41.Autorizacao(prepared, null)(Tentativa()));
    }

    [Fact]
    public async Task Autorizacao_nega_fora_do_escopo_funcional_mesmo_com_gate_ligado()
    {
        using var prepared = await PreparacaoBloqueadaAsync();
        var autorizar = SingleCreateDesktopBindingR41.Autorizacao(prepared, () => true);
        Assert.False(autorizar(Tentativa(acao: "UPDATE")));
        Assert.False(autorizar(Tentativa(bp: "20000015")));
        Assert.False(autorizar(Tentativa(codigo: "20000015")));
        Assert.False(autorizar(Tentativa(codigo: null)));
        // Payload nao identico ao preparado tambem e negado: a preparacao esta bloqueada, logo
        // EncodeWrite lanca e a autorizacao permanece fechada em vez de propagar excecao.
        Assert.False(autorizar(Tentativa()));
    }

    [Fact]
    public void Autorizacao_exige_preparacao()
        => Assert.Throws<ArgumentNullException>(() => SingleCreateDesktopBindingR41.Autorizacao(null!, () => true));

    // ---------- guard arquitetural ----------

    private static string RaizRepositorio()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !File.Exists(Path.Combine(dir, "FugaTES.slnx"))) dir = Path.GetDirectoryName(dir);
        return dir ?? throw new InvalidOperationException("RAIZ_NAO_LOCALIZADA");
    }

    // Guard focal: os arquivos INTRODUZIDOS por este delta na camada WinForms nao podem conter
    // infraestrutura de transporte. Nao enfraquece o guard global
    // (Arquitetura_WinFormsPermaneceSemHttpClient), que continua varrendo toda a WinForms.
    [Theory]
    [InlineData("Transportadoras/MasterdataR3/SingleCreateDesktopBindingR41.cs")]
    [InlineData("Transportadoras/MasterdataR3/MasterdataCategoryPreparationR42.cs")]
    public void Arquivos_do_delta_na_winforms_nao_contem_cliente_de_transporte(string relativo)
    {
        var caminho = Path.Combine(RaizRepositorio(), "src", "FugaTES.WinForms", relativo.Replace('/', Path.DirectorySeparatorChar));
        Assert.True(File.Exists(caminho), caminho);
        Assert.DoesNotContain("HttpClient", File.ReadAllText(caminho), StringComparison.OrdinalIgnoreCase);
    }

    // O transporte vive na camada de composicao, que legitimamente o conhece.
    [Fact]
    public void Fabrica_do_gateway_fica_fora_da_winforms()
    {
        var fabrica = Path.Combine(RaizRepositorio(), "src", "FugaTES.HostIntegracao", "SingleCreateGatewayFactoryR42.cs");
        Assert.True(File.Exists(fabrica), fabrica);
        Assert.Contains("HttpClient", File.ReadAllText(fabrica), StringComparison.Ordinal);
        Assert.Equal(typeof(SingleCreateGatewayFactoryR42).Assembly, typeof(CarrierProtocolBinding).Assembly);
    }

    [Fact]
    public void Fabrica_do_gateway_exige_todas_as_dependencias_de_transporte()
    {
        Assert.Throws<ArgumentNullException>(() => SingleCreateGatewayCompositionR42.Criar(null!, new(), null!));
        using var http = new HttpClient();
        Assert.Throws<ArgumentNullException>(() => SingleCreateGatewayCompositionR42.Criar(http, null!, null!));
    }
}
