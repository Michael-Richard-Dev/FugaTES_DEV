﻿using System.Security.Principal;
using FugaTES.HostIntegracao;
using FugaTES.WinForms.Transportadoras;
namespace FugaTES.SingleCreateJournal.R31.Tests;

// R117: valida INTEGRALMENTE o perfil aprovado contra os validadores reais, antes da publicacao.
// Tudo offline: nenhuma chamada SAP/Guardian e nenhum acesso a banco.
public sealed class CarrierProfileR117ReadyTests
{
    private static string Perfil()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !File.Exists(Path.Combine(dir, "FugaTES.slnx"))) dir = Path.GetDirectoryName(dir);
        var path = Path.Combine(dir!, ".staging-r108", "FugaTES.carrier.json.r117");
        Assert.True(File.Exists(path), path);
        return path;
    }

    private static string SidAtual() => WindowsIdentity.GetCurrent().User!.Value;

    [Fact]
    public void Perfil_aprovado_passa_no_validador_manual_para_o_bp_autorizado()
    {
        var config = CarrierDesktopProfile.Load(Perfil());
        // Nao lanca: todos os guardas do caminho manual estao satisfeitos.
        CarrierManualReadOnlyProfile.Validate(config, "20000014", SidAtual(), new DateTimeOffset(2026, 10, 16, 17, 0, 0, TimeSpan.Zero));
    }

    [Fact]
    public void Identidade_do_bp_esta_comprovada_com_o_idassinatura_atestado()
    {
        var config = CarrierDesktopProfile.Load(Perfil());
        var identidade = CarrierManualReadOnlyProfile.Identity(config, "20000014");
        Assert.NotNull(identidade);
        Assert.Equal("20000014", identidade!.Codigo);
        Assert.Equal("133289", identidade.IdAssinatura);
        Assert.True(identidade.Comprovada);
        Assert.False(string.IsNullOrWhiteSpace(identidade.Evidencia));
    }

    [Fact]
    public void Contrato_guardian_manual_esta_comprovado_e_o_ciclo_completo_nao()
    {
        var config = CarrierDesktopProfile.Load(Perfil());
        var manual = CarrierProtocolBinding.BuildGuardianManualContract(config);
        Assert.NotNull(manual);
        Assert.Equal("/api/v0/Guardian/Transportadora/{bp}?idAssinatura=133289", manual!.LookupRoute);
        Assert.True(manual.Scoped404Proven);
        // BusinessPartnerField nao foi inventado, entao o ciclo completo permanece nao comprovado.
        Assert.Null(CarrierProtocolBinding.BuildGuardianContract(config));
    }

    [Fact]
    public void Escrita_e_sincronizacao_automatica_permanecem_desabilitadas()
    {
        var config = CarrierDesktopProfile.Load(Perfil());
        foreach (var chave in new[]
        {
            "FUGATES_INTEGRATION_WORKER_ENABLED", "INC005_WORKER_ENABLED", "Carrier:IntegrationWorkerEnabled",
            "Carrier:DesktopGuardianWritesEnabled", "Carrier:Authorization:IncrementalReleased"
        })
        {
            Assert.True(bool.TryParse(config[chave], out var ligada), chave);
            Assert.False(ligada, chave);
        }
        Assert.False(CarrierDesktopProfile.True(config, "Carrier:SingleCreate:Enabled"));
    }

    [Fact]
    public void Autorizacao_expira_e_nao_cobre_outro_bp_nem_outro_sid()
    {
        var config = CarrierDesktopProfile.Load(Perfil());
        // Depois da validade, bloqueia.
        Assert.Throws<FugaTES.WinForms.Runtime.DesktopStartupException>(() =>
            CarrierManualReadOnlyProfile.Validate(config, "20000014", SidAtual(), new DateTimeOffset(2026, 10, 16, 21, 0, 1, TimeSpan.Zero)));
        // Outro BP, bloqueia.
        Assert.Throws<FugaTES.WinForms.Runtime.DesktopStartupException>(() =>
            CarrierManualReadOnlyProfile.Validate(config, "20000015", SidAtual(), new DateTimeOffset(2026, 10, 16, 17, 0, 0, TimeSpan.Zero)));
        // Outro SID, bloqueia.
        Assert.Throws<FugaTES.WinForms.Runtime.DesktopStartupException>(() =>
            CarrierManualReadOnlyProfile.Validate(config, "20000014", "S-1-5-21-0-0-0-9999", new DateTimeOffset(2026, 10, 16, 17, 0, 0, TimeSpan.Zero)));
    }

    [Fact]
    public void Perfil_nao_contem_credencial_em_texto_claro()
    {
        var texto = File.ReadAllText(Perfil());
        foreach (var proibido in new[] { "\"password\"", "\"pwd\"", "\"senha\"", "\"token\"", "\"assinatura\"", "\"secret\"" })
            Assert.DoesNotContain(proibido, texto, StringComparison.OrdinalIgnoreCase);
        // Sem BOM: CarrierDesktopProfile.Load usa JsonDocument.Parse(bytes), que rejeita BOM.
        Assert.NotEqual(0xEF, File.ReadAllBytes(Perfil())[0]);
    }
}
