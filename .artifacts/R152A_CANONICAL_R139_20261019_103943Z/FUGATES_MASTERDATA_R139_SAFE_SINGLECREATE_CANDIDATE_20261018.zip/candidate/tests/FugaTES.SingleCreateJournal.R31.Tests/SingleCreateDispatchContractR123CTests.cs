﻿using FugaTES.Aplicacao.Transportadoras;
using FugaTES.WinForms.Transportadoras.MasterdataR3;
namespace FugaTES.SingleCreateJournal.R31.Tests;

// R123C: contrato de pre-dispatch. Tudo offline — nenhum POST, GET, banco ou credencial.
// Nenhum valor empresarial do payload privado aparece aqui.
public sealed class SingleCreateDispatchContractR123CTests
{
    private static ProntidaoSingleCreateR122 Pronto() => new(true, []);
    private static ProntidaoSingleCreateR122 NaoPronto() => new(false, ["SINGLE_CREATE_DESKTOP_DISABLED"]);

    private static CarrierManualGuardian Ausente(bool comprovada = true)
        => new(CarrierLookupState.Absent, null, new Dictionary<string, string?>(), comprovada);
    private static CarrierManualGuardian Existente()
        => new(CarrierLookupState.Unique, "20000014", new Dictionary<string, string?>());

    private static PreDispatchDependenciasR123C Todas(
        bool journal = true, bool semPendente = true, CarrierManualGuardian? guardian = null, bool autorizado = true)
        => new()
        {
            JournalFisicoDisponivel = _ => Task.FromResult(journal),
            SemCreatePendente = _ => Task.FromResult(semPendente),
            ConsultaEscopada = _ => Task.FromResult(guardian ?? Ausente()),
            AutorizacaoPost = () => autorizado
        };

    // ---------- 6) fail-closed em cada pre-condicao ----------

    [Fact]
    public async Task Sem_prontidao_bloqueia_na_primeira_etapa()
    {
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(NaoPronto(), Todas(), default);
        Assert.False(r.Liberado);
        Assert.Equal(EtapaDispatchR123C.Prontidao, r.ParouEm);
        Assert.Contains("SINGLE_CREATE_DESKTOP_DISABLED", r.Codigo);
    }

    [Fact]
    public async Task Prontidao_ausente_bloqueia()
    {
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(null, Todas(), default);
        Assert.False(r.Liberado);
        Assert.Equal("SINGLE_CREATE_READINESS_ABSENT", r.Codigo);
    }

    [Fact]
    public async Task Dependencias_ausentes_bloqueiam_tudo()
    {
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), null, default);
        Assert.False(r.Liberado);
        Assert.Equal(EtapaDispatchR123C.JournalFisico, r.ParouEm);
        Assert.Equal("SINGLE_CREATE_JOURNAL_RUNTIME_NOT_ATTESTED", r.Codigo);
    }

    [Fact]
    public async Task Journal_indisponivel_bloqueia()
    {
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), Todas(journal: false), default);
        Assert.Equal(EtapaDispatchR123C.JournalFisico, r.ParouEm);
        Assert.Equal("SINGLE_CREATE_JOURNAL_MIGRATION_PENDING_GAIA", r.Codigo);
    }

    [Fact]
    public async Task Falha_no_preflight_do_journal_bloqueia_sem_propagar()
    {
        var deps = Todas() with { JournalFisicoDisponivel = _ => throw new InvalidOperationException("offline") };
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), deps, default);
        Assert.Equal("SINGLE_CREATE_JOURNAL_PREFLIGHT_FAILED", r.Codigo);
    }

    [Fact]
    public async Task Create_pendente_bloqueia()
    {
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), Todas(semPendente: false), default);
        Assert.Equal(EtapaDispatchR123C.CreatePendente, r.ParouEm);
        Assert.Equal("PENDING_OR_REPLAY_RECONCILIATION_REQUIRED", r.Codigo);
    }

    [Fact]
    public async Task Verificacao_de_pendencia_indisponivel_bloqueia()
    {
        var deps = Todas() with { SemCreatePendente = null };
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), deps, default);
        Assert.Equal("PENDING_OR_REPLAY_CHECK_NOT_AVAILABLE", r.Codigo);
    }

    // ---------- 7) nova consulta escopada antes do POST ----------

    [Fact]
    public async Task Consulta_escopada_ausente_bloqueia()
    {
        var deps = Todas() with { ConsultaEscopada = null };
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), deps, default);
        Assert.Equal(EtapaDispatchR123C.AusenciaGuardianEscopada, r.ParouEm);
        Assert.Equal("GUARDIAN_SCOPED_RECHECK_NOT_AVAILABLE", r.Codigo);
    }

    [Fact]
    public async Task Transportadora_ja_existente_bloqueia()
    {
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), Todas(guardian: Existente()), default);
        Assert.Equal(EtapaDispatchR123C.AusenciaGuardianEscopada, r.ParouEm);
        Assert.Equal("GUARDIAN_CREATE_ABSENCE_NOT_PROVEN", r.Codigo);
    }

    [Fact]
    public async Task Ausencia_nao_comprovada_por_404_escopado_bloqueia()
    {
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), Todas(guardian: Ausente(false)), default);
        Assert.Equal("GUARDIAN_CREATE_ABSENCE_NOT_PROVEN", r.Codigo);
    }

    [Fact]
    public async Task Consulta_escopada_e_executada_no_maximo_uma_vez_e_nao_e_repetida()
    {
        var chamadas = 0;
        var deps = Todas() with
        {
            ConsultaEscopada = _ => { chamadas++; return Task.FromResult(Ausente(false)); }
        };
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), deps, default);
        Assert.False(r.Liberado);
        Assert.Equal(1, chamadas);   // indeterminado/ausencia nao comprovada nao dispara reenvio
    }

    [Fact]
    public async Task Falha_na_consulta_escopada_bloqueia_sem_propagar()
    {
        var deps = Todas() with { ConsultaEscopada = _ => throw new TimeoutException("offline") };
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), deps, default);
        Assert.Equal("GUARDIAN_SCOPED_RECHECK_FAILED", r.Codigo);
    }

    // ---------- autorizacao especifica de POST ----------

    [Fact]
    public async Task Sem_autorizacao_de_post_bloqueia_mesmo_com_tudo_pronto()
    {
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), Todas(autorizado: false), default);
        Assert.Equal(EtapaDispatchR123C.AutorizacaoPost, r.ParouEm);
        Assert.Equal("SINGLE_CREATE_DISPATCH_NOT_AUTHORIZED", r.Codigo);
    }

    [Fact]
    public async Task Autorizacao_que_lanca_e_tratada_como_negada()
    {
        var deps = Todas() with { AutorizacaoPost = () => throw new InvalidOperationException() };
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), deps, default);
        Assert.Equal("SINGLE_CREATE_DISPATCH_NOT_AUTHORIZED", r.Codigo);
    }

    [Fact]
    public async Task Cancelamento_bloqueia()
    {
        using var cts = new CancellationTokenSource();
        await cts.CancelAsync();
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), Todas(), cts.Token);
        Assert.False(r.Liberado);
        Assert.Equal("SINGLE_CREATE_CANCELLED", r.Codigo);
    }

    // ---------- ordem das etapas ----------

    [Fact]
    public async Task A_ordem_das_etapas_e_respeitada()
    {
        // Journal falho mascara as etapas seguintes: elas nem sao consultadas.
        var consultou = false;
        var deps = Todas(journal: false) with
        {
            ConsultaEscopada = _ => { consultou = true; return Task.FromResult(Ausente()); }
        };
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), deps, default);
        Assert.Equal(EtapaDispatchR123C.JournalFisico, r.ParouEm);
        Assert.False(consultou);
    }

    [Fact]
    public async Task Com_todas_as_pre_condicoes_apenas_libera_para_despacho()
    {
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(Pronto(), Todas(), default);
        Assert.True(r.Liberado);
        Assert.Equal(EtapaDispatchR123C.LiberadoParaDespacho, r.ParouEm);
        // Liberar nao e postar: o POST continua sendo do GuardianSingleCreateUseCaseR31.
        Assert.Equal("SINGLE_CREATE_PRE_DISPATCH_OK", r.Codigo);
    }
}
