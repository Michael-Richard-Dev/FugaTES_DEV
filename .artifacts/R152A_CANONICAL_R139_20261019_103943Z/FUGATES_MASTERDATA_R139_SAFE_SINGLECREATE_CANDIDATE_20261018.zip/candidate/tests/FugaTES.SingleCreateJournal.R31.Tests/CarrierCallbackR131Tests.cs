﻿using FugaTES.WinForms.Transportadoras;
using FugaTES.WinForms.Transportadoras.MasterdataR3;
using Microsoft.Extensions.Configuration;
namespace FugaTES.SingleCreateJournal.R31.Tests;

// R131: perfil de ENSAIO HML com callback aprovado. Tudo offline.
// Nenhum valor empresarial, nenhuma URL completa e nenhum CNPJ aparece neste arquivo.
public sealed class CarrierCallbackR131Tests
{
    private static readonly DateTimeOffset Agora = new(2026, 10, 16, 18, 0, 0, TimeSpan.Zero);
    private const string Sid = "S-1-5-21-0-0-0-1000";

    private static string Raiz()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !File.Exists(Path.Combine(dir, "FugaTES.slnx"))) dir = Path.GetDirectoryName(dir);
        return dir!;
    }

    private static string PerfilEnsaio() => Path.Combine(Raiz(), ".staging-r131", "FugaTES.carrier.r131.json");
    private static string PerfilPublicado() => @"C:\FugaTES_DEV110\FugaTES.carrier.json";

    // ---------- 3) separacao entre ensaio e producao ----------

    [Fact]
    public void Perfil_de_ensaio_existe_e_esta_marcado_como_nao_publicavel()
    {
        Assert.True(File.Exists(PerfilEnsaio()));
        var texto = File.ReadAllText(PerfilEnsaio());
        Assert.Contains("ENSAIO HML R131", texto, StringComparison.Ordinal);
        Assert.Contains("NUNCA publicar", texto, StringComparison.Ordinal);
    }

    [Fact]
    public void Perfil_publicado_nao_contem_configuracao_de_ensaio()
    {
        if (!File.Exists(PerfilPublicado())) return;   // ambiente sem DEV110 instalado
        var texto = File.ReadAllText(PerfilPublicado());
        Assert.DoesNotContain("SingleCreate", texto, StringComparison.Ordinal);
        Assert.DoesNotContain("CallbackUrl", texto, StringComparison.Ordinal);
    }

    // ---------- 5) CREATE continua desabilitado ate o journal ----------

    [Fact]
    public void Ensaio_mantem_single_create_desabilitado()
    {
        var config = CarrierDesktopProfile.Load(PerfilEnsaio());
        Assert.False(CarrierDesktopProfile.True(config, "Carrier:SingleCreate:Enabled"));
    }

    [Fact]
    public void Ensaio_sem_journal_comprovado_permanece_bloqueado()
    {
        var config = CarrierDesktopProfile.Load(PerfilEnsaio());
        var p = SingleCreateDesktopGateR122.Avaliar("20000014", Agora, Sid, config, journalFisicoComprovado: false);
        Assert.False(p.Pronto);
        Assert.Contains("SINGLE_CREATE_JOURNAL_RUNTIME_NOT_ATTESTED", p.Bloqueios);
    }

    // ---------- 6) CALLBACK_EMPTY=PROHIBITED ----------

    [Fact]
    public void Callback_de_ensaio_esta_configurado_e_deixou_de_bloquear()
    {
        var config = CarrierDesktopProfile.Load(PerfilEnsaio());
        Assert.True(CarrierDesktopProfile.True(config, SingleCreateDesktopGateR122.ChaveCallbackAprovado));
        var url = config[SingleCreateDesktopGateR122.ChaveCallback];
        // Valida a FORMA, nunca o valor: https absoluta, sem userinfo e sem fragmento.
        Assert.False(string.IsNullOrWhiteSpace(url));
        Assert.True(Uri.TryCreate(url, UriKind.Absolute, out var destino));
        Assert.Equal(Uri.UriSchemeHttps, destino!.Scheme);
        Assert.Empty(destino.UserInfo);
        Assert.Empty(destino.Fragment);
        var p = SingleCreateDesktopGateR122.Avaliar("20000014", Agora, Sid, config, journalFisicoComprovado: true);
        Assert.DoesNotContain("CREATE_CALLBACK_HML_NOT_APPROVED", p.Bloqueios);
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("http://inseguro.invalid/cb")]
    [InlineData("/relativo")]
    public void Callback_vazio_ou_invalido_continua_proibido(string valor)
    {
        // Config sintetica sobre o perfil de ensaio: CALLBACK_EMPTY=PROHIBITED permanece travado,
        // independentemente do que estiver gravado no arquivo.
        var pares = CarrierDesktopProfile.Load(PerfilEnsaio())
            .AsEnumerable().ToDictionary(p => p.Key, p => p.Value, StringComparer.OrdinalIgnoreCase);
        pares[SingleCreateDesktopGateR122.ChaveCallback] = valor;
        var config = new ConfigurationBuilder()
            .AddInMemoryCollection(pares).Build();
        var p = SingleCreateDesktopGateR122.Avaliar("20000014", Agora, Sid, config, journalFisicoComprovado: true);
        Assert.False(p.Pronto);
        Assert.Contains("CREATE_CALLBACK_HML_NOT_APPROVED", p.Bloqueios);
    }

    [Fact]
    public void Historico_reconciliado_deixa_de_bloquear_no_perfil_de_ensaio()
    {
        var config = CarrierDesktopProfile.Load(PerfilEnsaio());
        var p = SingleCreateDesktopGateR122.Avaliar("20000014", Agora, Sid, config, journalFisicoComprovado: true);
        // Decisao R123 da Hera: HISTORICAL_POST=RECONCILED.
        Assert.DoesNotContain("HISTORICAL_POST_NOT_RECONCILED", p.Bloqueios);
    }

    // ---------- 6) a interface nao permite POST sem as cinco condicoes ----------

    [Fact]
    public async Task Sem_as_cinco_condicoes_o_contrato_nunca_libera_despacho()
    {
        var config = CarrierDesktopProfile.Load(PerfilEnsaio());
        var prontidao = SingleCreateDesktopGateR122.Avaliar("20000014", Agora, Sid, config, journalFisicoComprovado: false);
        var r = await SingleCreateDispatchContractR123C.VerificarAsync(prontidao, null, default);
        Assert.False(r.Liberado);
        Assert.Equal(EtapaDispatchR123C.Prontidao, r.ParouEm);
    }

    [Fact]
    public void Autorizacao_temporal_vencida_bloqueia_no_perfil_de_ensaio()
    {
        var config = CarrierDesktopProfile.Load(PerfilEnsaio());
        var depois = new DateTimeOffset(2026, 10, 18, 0, 0, 0, TimeSpan.Zero);
        var p = SingleCreateDesktopGateR122.Avaliar("20000014", depois, Sid, config, journalFisicoComprovado: true);
        Assert.False(p.Pronto);
        Assert.Contains("SINGLE_CREATE_AUTHORIZATION_EXPIRED", p.Bloqueios);
    }

    // ---------- 4) formato do envelope, sem expor valores ----------

    [Fact]
    public void Envelope_do_payload_tem_a_forma_exata_do_r37()
    {
        var pf = Path.Combine(Raiz(), ".staging-r123", "saida-privada", "PAYLOAD_REAL_R123.json");
        if (!File.Exists(pf)) return;   // artefato privado pode nao estar acessivel
        using var doc = System.Text.Json.JsonDocument.Parse(File.ReadAllText(pf));
        var raiz = doc.RootElement;
        Assert.True(raiz.TryGetProperty("voConfiguracao", out var vo));
        Assert.True(vo.TryGetProperty("urlParaRetorno", out _));
        Assert.True(raiz.TryGetProperty("entidadeTransportadora", out var ent));
        var campos = ent.EnumerateObject().Select(p => p.Name).OrderBy(n => n, StringComparer.Ordinal).ToArray();
        Assert.Equal(["cnpj", "codigo", "descricao", "estado", "razaoSocial", "sequencial"], campos);
        Assert.Equal("20000014", ent.GetProperty("codigo").GetString());
        Assert.Equal(1, ent.GetProperty("estado").GetInt32());
        Assert.Equal(0, ent.GetProperty("sequencial").GetInt32());
        // Comprimentos dentro do limite; os VALORES nunca sao lidos para log ou assercao.
        Assert.InRange(ent.GetProperty("descricao").GetString()!.Length, 1, 50);
        Assert.InRange(ent.GetProperty("razaoSocial").GetString()!.Length, 1, 50);
        Assert.Equal(14, ent.GetProperty("cnpj").GetString()!.Length);
    }
}
