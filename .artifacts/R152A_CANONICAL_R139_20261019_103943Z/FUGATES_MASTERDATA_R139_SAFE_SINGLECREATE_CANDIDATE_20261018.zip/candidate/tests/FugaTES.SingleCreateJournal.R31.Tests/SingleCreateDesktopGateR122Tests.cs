﻿using FugaTES.WinForms.Transportadoras;
using FugaTES.WinForms.Transportadoras.MasterdataR3;
using Microsoft.Extensions.Configuration;
namespace FugaTES.SingleCreateJournal.R31.Tests;

// R122: prontidao do CREATE unitario. Tudo offline: nenhuma consulta SAP/Guardian, nenhum banco.
public sealed class SingleCreateDesktopGateR122Tests
{
    private static readonly DateTimeOffset Agora = new(2026, 10, 16, 18, 0, 0, TimeSpan.Zero);
    private const string Sid = "S-1-5-21-0-0-0-1000";

    // Perfil COMPLETO e hipotetico, usado so para provar que cada guarda isolado bloqueia.
    private static Dictionary<string, string?> Completo() => new()
    {
        ["Carrier:Environment"] = "HML",
        ["Carrier:SingleCreate:Enabled"] = "true",
        ["Carrier:SingleCreate:CallbackUrl"] = "https://callback.invalid/guardian/transportadora",
        ["Carrier:SingleCreate:CallbackApproved"] = "true",
        ["Carrier:SingleCreate:HistoricalPostReconciled"] = "true",
        ["Carrier:Authorization:UntilUtc"] = "2026-10-16T21:00:00Z",
        ["Carrier:Authorization:AllowedBps:0"] = "20000014",
        ["Carrier:Authorization:AllowedSids:0"] = Sid,
        ["Carrier:ManualReadOnly:Identities:20000014:Proven"] = "true",
        ["Carrier:ManualReadOnly:Identities:20000014:Code"] = "20000014",
        ["Carrier:ManualReadOnly:Identities:20000014:GetSignatureId"] = "133289",
        ["Carrier:ManualReadOnly:Identities:20000014:ApprovalReference"] = "OFFLINE_REF",
        ["Carrier:Protocols:Guardian:Environment"] = "HML",
        ["Carrier:Protocols:Guardian:ProfileVerified"] = "true",
        ["Carrier:Protocols:Guardian:SignatureVerified"] = "true",
        ["Carrier:Protocols:Guardian:ApprovalReference"] = "OFFLINE_REF",
        ["Carrier:Protocols:Guardian:LookupRoute"] = "/api/v0/Guardian/Transportadora/{bp}?idAssinatura=133289",
        ["Carrier:Protocols:Guardian:CreateRoute"] = "/api/v0/Guardian/Transportadora",
        ["Carrier:Protocols:Guardian:UpdateRoute"] = "/api/v0/Guardian/Transportadora",
        ["Carrier:Protocols:Guardian:ReadbackRoute"] = "/api/v0/Guardian/Transportadora/{code}",
        ["Carrier:Protocols:Guardian:AbsenceHttpStatus"] = "404",
        ["Carrier:Protocols:Guardian:RowsPath"] = "$",
        ["Carrier:Protocols:Guardian:BusinessPartnerField"] = "OfflineBp",
        ["Carrier:Protocols:Guardian:CodeField"] = "codigo",
        ["Carrier:Protocols:Guardian:NameField"] = "descricao",
        ["Carrier:Protocols:Guardian:LegalNameField"] = "razaoSocial",
        ["Carrier:Protocols:Guardian:WriteCodeField"] = "codigo",
        ["Carrier:Protocols:Guardian:WriteNameField"] = "descricao",
        ["Carrier:Protocols:Guardian:WriteLegalNameField"] = "razaoSocial",
        ["Carrier:Protocols:Guardian:ResponseCodePath"] = "codigo"
    };

    private static IConfiguration Config(Action<Dictionary<string, string?>>? mutate = null)
    {
        var v = Completo();
        mutate?.Invoke(v);
        return new ConfigurationBuilder().AddInMemoryCollection(v).Build();
    }

    private static ProntidaoSingleCreateR122 Avaliar(IConfiguration c, bool journal = true, string bp = "20000014")
        => SingleCreateDesktopGateR122.Avaliar(bp, Agora, Sid, c, journal);

    // ---------- o perfil REAL publicado nao pode liberar o CREATE ----------

    [Fact]
    public void Perfil_r117_publicado_nao_libera_o_create()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !File.Exists(Path.Combine(dir, "FugaTES.slnx"))) dir = Path.GetDirectoryName(dir);
        var perfil = CarrierDesktopProfile.Load(Path.Combine(dir!, ".staging-r108", "FugaTES.carrier.json.r117"));
        var p = SingleCreateDesktopGateR122.Avaliar("20000014", Agora, Sid, perfil, journalFisicoComprovado: false);
        Assert.False(p.Pronto);
        // Os quatro bloqueios materiais do R121 continuam presentes.
        Assert.Contains("SINGLE_CREATE_DESKTOP_DISABLED", p.Bloqueios);
        Assert.Contains("CREATE_CALLBACK_HML_NOT_APPROVED", p.Bloqueios);
        Assert.Contains("HISTORICAL_POST_NOT_RECONCILED", p.Bloqueios);
        Assert.Contains("SINGLE_CREATE_JOURNAL_RUNTIME_NOT_ATTESTED", p.Bloqueios);
    }

    // ---------- cada guarda isolado bloqueia ----------

    [Fact]
    public void Perfil_completo_e_journal_comprovado_ficam_prontos_mas_nao_autorizam_dispatch()
    {
        var p = Avaliar(Config());
        Assert.True(p.Pronto);
        Assert.Empty(p.Bloqueios);
        Assert.Equal("SINGLE_CREATE_PRONTO_AGUARDANDO_AUTORIZACAO_DE_DISPATCH", p.Resumo);
    }

    [Fact]
    public void Journal_fisico_nao_comprovado_bloqueia()
    {
        var p = Avaliar(Config(), journal: false);
        Assert.False(p.Pronto);
        Assert.Contains("SINGLE_CREATE_JOURNAL_RUNTIME_NOT_ATTESTED", p.Bloqueios);
    }

    [Fact]
    public void Chave_de_liberacao_ausente_bloqueia()
        => Assert.Contains("SINGLE_CREATE_DESKTOP_DISABLED",
            Avaliar(Config(v => v["Carrier:SingleCreate:Enabled"] = "false")).Bloqueios);

    [Theory]
    [InlineData("Carrier:SingleCreate:CallbackApproved", "false")]
    [InlineData("Carrier:SingleCreate:CallbackUrl", "")]
    [InlineData("Carrier:SingleCreate:CallbackUrl", "http://inseguro.invalid/cb")]
    [InlineData("Carrier:SingleCreate:CallbackUrl", "/relativo")]
    [InlineData("Carrier:SingleCreate:CallbackUrl", "https://cb.invalid/x#frag")]
    public void Callback_nao_aprovado_ou_invalido_bloqueia(string chave, string valor)
        => Assert.Contains("CREATE_CALLBACK_HML_NOT_APPROVED", Avaliar(Config(v => v[chave] = valor)).Bloqueios);

    [Fact]
    public void Post_historico_nao_reconciliado_bloqueia()
        => Assert.Contains("HISTORICAL_POST_NOT_RECONCILED",
            Avaliar(Config(v => v["Carrier:SingleCreate:HistoricalPostReconciled"] = "false")).Bloqueios);

    [Fact]
    public void Identidade_do_bp_nao_comprovada_bloqueia()
        => Assert.Contains("GUARDIAN_BP_CODE_BINDING_NOT_PROVEN",
            Avaliar(Config(v => v["Carrier:ManualReadOnly:Identities:20000014:ApprovalReference"] = "")).Bloqueios);

    [Fact]
    public void Contrato_guardian_incompleto_bloqueia()
        => Assert.Contains("CARRIER_DESKTOP_GUARDIAN_HML_NOT_PROVEN",
            Avaliar(Config(v => v["Carrier:Protocols:Guardian:BusinessPartnerField"] = "")).Bloqueios);

    [Fact]
    public void Autorizacao_expirada_bloqueia()
        => Assert.Contains("SINGLE_CREATE_AUTHORIZATION_EXPIRED",
            Avaliar(Config(v => v["Carrier:Authorization:UntilUtc"] = "2026-10-16T17:00:00Z")).Bloqueios);

    [Fact]
    public void Outro_bp_e_outro_sid_bloqueiam()
    {
        Assert.Contains("SINGLE_CREATE_BP_NOT_AUTHORIZED", Avaliar(Config(), bp: "20000015").Bloqueios);
        Assert.Contains("SINGLE_CREATE_SID_NOT_AUTHORIZED",
            SingleCreateDesktopGateR122.Avaliar("20000014", Agora, "S-1-5-21-0-0-0-9999", Config(), true).Bloqueios);
    }

    [Theory]
    [InlineData("FUGATES_INTEGRATION_WORKER_ENABLED")]
    [InlineData("INC005_WORKER_ENABLED")]
    [InlineData("Carrier:IntegrationWorkerEnabled")]
    public void Sincronizacao_automatica_ligada_bloqueia(string chave)
        => Assert.Contains("AUTOMATIC_SYNC_MUST_REMAIN_DISABLED", Avaliar(Config(v => v[chave] = "true")).Bloqueios);

    [Fact]
    public void Bp_invalido_bloqueia_antes_de_ler_o_perfil()
    {
        var p = SingleCreateDesktopGateR122.Avaliar("bp invalido!", Agora, Sid, Config(), true);
        Assert.False(p.Pronto);
        Assert.Equal(["SINGLE_CREATE_BP_INVALIDO"], p.Bloqueios);
    }

    [Fact]
    public void Todos_os_bloqueios_sao_reportados_juntos()
    {
        var p = Avaliar(Config(v =>
        {
            v["Carrier:SingleCreate:Enabled"] = "false";
            v["Carrier:SingleCreate:CallbackApproved"] = "false";
            v["Carrier:SingleCreate:HistoricalPostReconciled"] = "false";
        }), journal: false);
        Assert.False(p.Pronto);
        Assert.True(p.Bloqueios.Count >= 4);
        // O resumo lista as causas, para o operador saber exatamente o que falta.
        Assert.Contains("SINGLE_CREATE_DESKTOP_DISABLED", p.Resumo);
    }
}
