﻿using FugaTES.HostIntegracao;
using FugaTES.WinForms.Runtime;
using FugaTES.WinForms.Transportadoras;
namespace FugaTES.SingleCreateJournal.R31.Tests;

// Proposta de perfil HML (R108). Verifica contra os validadores REAIS que a proposta:
//  - nao carrega segredo em texto claro;
//  - permanece fail-closed enquanto houver campo pendente;
//  - nao habilita escrita nem sincronizacao automatica.
// Nenhuma consulta SAP/Guardian e nenhum acesso a banco ocorre aqui.
public sealed class CarrierProfileProposalR108Tests
{
    private static string Proposta()
    {
        var dir = AppContext.BaseDirectory;
        while (dir is not null && !File.Exists(Path.Combine(dir, "FugaTES.slnx"))) dir = Path.GetDirectoryName(dir);
        Assert.NotNull(dir);
        var path = Path.Combine(dir!, ".staging-r108", "FugaTES.carrier.json.proposta");
        Assert.True(File.Exists(path), path);
        return path;
    }

    [Fact]
    public void Proposta_carrega_sem_segredo_em_texto_claro()
    {
        // CarrierDesktopProfile.Load rejeita qualquer chave password/pwd/token/signature/assinatura/connectionstring.
        var config = CarrierDesktopProfile.Load(Proposta());
        Assert.Equal("HML", config["Carrier:Environment"]);
    }

    [Fact]
    public void Proposta_mantem_todas_as_flags_de_escrita_e_worker_em_false()
    {
        var config = CarrierDesktopProfile.Load(Proposta());
        foreach (var key in new[]
        {
            "FUGATES_INTEGRATION_WORKER_ENABLED", "INC005_WORKER_ENABLED",
            "Carrier:IntegrationWorkerEnabled", "Carrier:DesktopGuardianWritesEnabled",
            "Carrier:Authorization:IncrementalReleased"
        })
        {
            Assert.True(bool.TryParse(config[key], out var flag), key);
            Assert.False(flag, key);
        }
        // A chave que habilitaria o CREATE unitario nao existe na proposta.
        Assert.False(CarrierDesktopProfile.True(config, "Carrier:SingleCreate:Enabled"));
    }

    [Fact]
    public void Contrato_guardian_permanece_nao_comprovado_enquanto_houver_pendencia()
    {
        var config = CarrierDesktopProfile.Load(Proposta());
        // BusinessPartnerField vazio -> contrato nulo. Nenhuma rota Guardian e considerada comprovada.
        Assert.Null(CarrierProtocolBinding.BuildGuardianContract(config));
    }

    [Fact]
    public void Consulta_manual_permanece_bloqueada_fail_closed()
    {
        var config = CarrierDesktopProfile.Load(Proposta());
        var erro = Assert.Throws<DesktopStartupException>(() =>
            CarrierManualReadOnlyProfile.Validate(config, "20000014", "S-1-5-21-0-0-0-1000", DateTimeOffset.UtcNow));
        // Com a referencia de aprovacao R16 ja legitima, o primeiro guarda nao atendido passa a ser
        // o contrato de leitura individual SAP, ainda sem referencia aprovada.
        Assert.Equal("MANUAL_SAP_INDIVIDUAL_CONTRACT_NOT_PROVEN", erro.Code);
    }

    [Fact]
    public void Escopo_autorizado_cobre_somente_o_bp_do_primeiro_cenario()
    {
        var config = CarrierDesktopProfile.Load(Proposta());
        var bps = config.GetSection("Carrier:Authorization:AllowedBps").GetChildren().Select(c => c.Value!).ToArray();
        Assert.Equal(["20000014"], bps);
        Assert.Null(CarrierManualReadOnlyProfile.Identity(config, "20000015"));
    }

    // R112: idAssinatura 133289 atestado pelo usuario de negocio.
    [Fact]
    public void Rota_get_guardian_usa_o_idassinatura_atestado()
    {
        var config = CarrierDesktopProfile.Load(Proposta());
        var rota = config["Carrier:Protocols:Guardian:LookupRoute"]!;
        var codigo = config["Carrier:ManualReadOnly:Identities:20000014:Code"]!;
        // O adapter substitui {bp} pelo CODIGO Guardian da identidade, nao pelo BP SAP.
        Assert.Equal("/api/v0/Guardian/Transportadora/20000014?idAssinatura=133289", rota.Replace("{bp}", codigo));
    }

    [Fact]
    public void Idassinatura_da_rota_casa_com_a_identidade_do_bp()
    {
        var config = CarrierDesktopProfile.Load(Proposta());
        var id = config["Carrier:ManualReadOnly:Identities:20000014:GetSignatureId"]!;
        Assert.Equal("133289", id);
        Assert.All(id, c => Assert.True(c is >= '0' and <= '9'));
        Assert.True(id.Length <= 64);
        // O adapter exige exatamente um idAssinatura igual ao da identidade.
        Assert.Contains("idAssinatura=" + id, config["Carrier:Protocols:Guardian:LookupRoute"]!);
    }

    [Fact]
    public void Assinatura_do_createtoken_permanece_separada_do_idassinatura()
    {
        var config = CarrierDesktopProfile.Load(Proposta());
        // Mesmo que os valores coincidissem, sao chaves distintas e de origens distintas:
        // a assinatura do CreateToken vem do Gerenciador de Credenciais; o idAssinatura e escopo de GET.
        Assert.Equal("FugaTES/HML/Guardian/Signature", config["Carrier:Secrets:GuardianSignatureTarget"]);
        Assert.Equal("FugaTES-HML-Signature", config["Carrier:Secrets:GuardianSignatureUser"]);
        Assert.Null(config["Carrier:Secrets:GetSignatureId"]);
        Assert.Null(config["Carrier:ManualReadOnly:Identities:20000014:GuardianSignatureTarget"]);
    }

    [Fact]
    public void Identidade_segue_nao_comprovada_por_falta_de_referencia_de_aprovacao()
    {
        var config = CarrierDesktopProfile.Load(Proposta());
        Assert.True(string.IsNullOrWhiteSpace(config["Carrier:ManualReadOnly:Identities:20000014:ApprovalReference"]));
        Assert.Null(CarrierManualReadOnlyProfile.Identity(config, "20000014"));
    }

    [Fact]
    public void Sids_autorizados_permanecem_vazios_ate_comprovacao()
    {
        var config = CarrierDesktopProfile.Load(Proposta());
        Assert.Empty(config.GetSection("Carrier:Authorization:AllowedSids").GetChildren());
    }
}
