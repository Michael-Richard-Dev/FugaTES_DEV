using System.Text.Json;
using System.Text.Json.Serialization;
using FugaTES.Aplicacao.Servicos.Mvp;
namespace FugaTES.Integracao.Guardian;

public sealed record GuardianPreCadastroAcmR57RequestDto(
    [property:JsonPropertyName("configuracao")] GuardianPreCadastroConfiguracaoDto Configuracao,
    [property:JsonPropertyName("dadosProtocoloPreCadastro")] DadosPreCadastroAcmR57 DadosProtocoloPreCadastro);
public sealed partial class GuardianSet26HttpClient : IAcmPreCadastroMinimoGatewayR57
{
    public static GuardianPreCadastroAcmR57RequestDto CriarPayloadR57(PreCadastroAcmR57 request)
    {
        AcmR57Mapping.Validar(request);
        return new(new(request.Callback),request.Dados);
    }
    public async Task<ProtocoloAcmR57> EnviarMinimoAcmAsync(PreCadastroAcmR57 request,CancellationToken ct)
    {
        var payload=CriarPayloadR57(request);
        const string route="/api/v1/Guardian/ProtocoloPreCadastro";
        if(options.PreCadastroEndpoint!=route || options.BaseUrl?.Scheme!="https")
            throw new GuardianHttpException("Guardian R57 REST route/profile is invalid.");
        using var response=await SendAsync(options.ResolveEndpoint(route,nameof(options.PreCadastroEndpoint)),payload,ct);
        try
        {
            using var doc=JsonDocument.Parse(await response.Content.ReadAsStreamAsync(ct));var r=doc.RootElement;
            if(r.ValueKind!=JsonValueKind.Object || r.EnumerateObject().GroupBy(p=>p.Name,StringComparer.Ordinal).Any(g=>g.Count()!=1))
                throw new GuardianHttpException("Guardian R57 response is ambiguous.");
            string Text(string key)=>r.TryGetProperty(key,out var v)&&v.ValueKind==JsonValueKind.String?v.GetString()!:"";
            if(!r.TryGetProperty("id",out var id)||!id.TryGetInt64(out var n)||n<=0)
                throw new GuardianHttpException("Guardian R57 protocol identity is invalid.");
            string? ticket=null;
            if(r.TryGetProperty("numeroTicket",out var t)&&t.ValueKind!=JsonValueKind.Null)
            {
                if(t.ValueKind!=JsonValueKind.String||string.IsNullOrWhiteSpace(t.GetString()))throw new GuardianHttpException("Guardian R57 ticket is invalid.");
                ticket=t.GetString();
            }
            var result=new ProtocoloAcmR57(n,Text("codigoContrato"),Text("codigoItem"),Text("codigoEmissor"),Text("numeroReferencia"),ticket);
            if(!AcmR57Mapping.RespostaConfere(result,request))throw new GuardianHttpException("Guardian R57 response identity does not match.");
            return result;
        }
        catch(JsonException ex){throw new GuardianHttpException("Guardian R57 response is invalid.",ex);}
    }
}
