namespace FugaTES.WinForms;

public partial class PainelInicialForm : Form
{
    private readonly Color corMenuAtivo = Color.FromArgb(34, 102, 141);
    private readonly Color corMenuPadrao = Color.FromArgb(38, 43, 51);

    private readonly Transportadoras.CarrierDesktopLifecycle? carrier;
    private readonly Transportadoras.SafeDemoReadOnlySessionR50? demo;
    private bool carrierStopping,carrierStopped;
    public PainelInicialForm(Transportadoras.CarrierDesktopLifecycle? carrier=null,Transportadoras.SafeDemoReadOnlySessionR50? demo=null)
    {
        this.carrier=carrier;this.demo=demo;
        InitializeComponent();
        SelecionarBotaoMenu(BtnInicio);
        LblAmbiente.Text = "Ambiente: " + Runtime.DesktopRuntime.EnvironmentDisplay;
        LblSubtituloSistema.Text = "Ambiente " + Runtime.DesktopRuntime.EnvironmentDisplay + " — consultas operacionais";
        LblBanco.Text = Runtime.DesktopRuntime.Connected ? "Banco: Conectado" : "Banco: Não conectado";
        LblResumoConteudo.Text = Runtime.DesktopRuntime.Connected
            ? "PostgreSQL validado. Desktop em modo somente leitura."
            : Runtime.DesktopRuntime.FailureText;
        if(demo is not null){
            Text=File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.execution.R57.json"))?"FugaTES — DEMO R57 — OFFLINE":File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.preview.R55.json"))?"FugaTES — DEMO R55 — OFFLINE":File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.preview.R53.json"))?"FugaTES — DEMO R53 — SOMENTE LEITURA":demo.GuardianRead is null?"FugaTES — DEMO R50 — SOMENTE LEITURA":"FugaTES — DEMO R50B — SOMENTE LEITURA";
            LblResumoConteudo.AutoSize=false;
            LblResumoConteudo.Size=new Size(Math.Max(300,PnlConteudo.ClientSize.Width-56),180);
            LblResumoConteudo.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;
            MostrarDemo();
        }
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        if(demo is not null)return;
        carrier?.Start();
        if (Runtime.DesktopRuntime.Connected) BtnMonitoramento_Click(this, EventArgs.Empty);
    }

    protected override async void OnFormClosing(FormClosingEventArgs e)
    {
        if(demo is not null&&!carrierStopped){e.Cancel=true;base.OnFormClosing(e);if(carrierStopping)return;carrierStopping=true;await demo.StopAsync();carrierStopped=true;Close();return;}
        if(carrier is null||carrierStopped){base.OnFormClosing(e);return;}
        e.Cancel=true;base.OnFormClosing(e);
        if(carrierStopping)return;
        carrierStopping=true;LblResumoConteudo.Text="Encerrando sincronização de transportadoras com segurança...";
        await carrier.StopAsync();
        carrierStopped=true;Close();
    }

    private void BtnInicio_Click(object? sender, EventArgs e)
    {
        SelecionarBotaoMenu(BtnInicio);
        LblAmbiente.Text = "Ambiente: " + Runtime.DesktopRuntime.EnvironmentDisplay;
        LblSubtituloSistema.Text = "Ambiente " + Runtime.DesktopRuntime.EnvironmentDisplay + " — consultas operacionais";
        LblBanco.Text = Runtime.DesktopRuntime.Connected ? "Banco: Conectado" : "Banco: Não conectado";
        LblResumoConteudo.Text = Runtime.DesktopRuntime.Connected
            ? "PostgreSQL validado. Desktop em modo somente leitura."
            : Runtime.DesktopRuntime.FailureText;
        LblTituloConteudo.Text = "Início";
        if(demo is not null){MostrarDemo();return;}
        LblResumoConteudo.Text = Runtime.DesktopRuntime.Connected ? "PostgreSQL validado. Desktop em modo somente leitura." : Runtime.DesktopRuntime.FailureText;
    }

    private void BtnIntegracoes_Click(object? sender, EventArgs e)
    {
        SelecionarBotaoMenu(BtnIntegracoes);
        LblTituloConteudo.Text = "Integrações";
        LblResumoConteudo.Text = "Contratos ACM e Cadastros SAP → Guardian";
        using var contratos = new FrmIntegracoes(carrier,demo);
        contratos.ShowDialog(this);
    }

    private void BtnMonitoramento_Click(object? sender, EventArgs e)
    {
        SelecionarBotaoMenu(BtnMonitoramento);
        LblTituloConteudo.Text = "Monitoramento";
        if(demo is not null){LblResumoConteudo.Text="Monitor operacional: PostgreSQL DEV não conectado. Atualizações automáticas desabilitadas.";return;}
        using var monitor = Monitor.MonitorComposition.Criar();
        monitor.ShowDialog(this);
    }

    private void BtnConfiguracoes_Click(object? sender, EventArgs e)
    {
        SelecionarBotaoMenu(BtnConfiguracoes);
        LblTituloConteudo.Text = "Configurações";
        if(demo is not null){MostrarDemo();return;}
        LblResumoConteudo.Text = Runtime.DesktopRuntime.Connected ? "Configuração HML validada; segredos protegidos pelo Windows." : Runtime.DesktopRuntime.FailureText;
    }

    private void MostrarDemo()
    {
        LblAmbiente.Text=File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.execution.R57.json"))?"Demo R57":File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.preview.R55.json"))?"Demo R55":File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.preview.R53.json"))?"Demo R53":demo?.GuardianRead is null?"Demo R50":"Demo R50B";
        LblVersao.Text="Somente leitura";
        LblSap.Text="SAP: manual";
        LblToledo.Visible=false;
        LblBanco.Location=LblToledo.Location;
        LblSubtituloSistema.Text="Consultas manuais — sem sincronização automática";
        LblBanco.Text="PostgreSQL DEV: NÃO CONECTADO";
        if(File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.execution.R57.json")))
        {
            LblResumoConteudo.Text="R57 — OFFLINE / SEM ESCRITAS\r\n\r\nFluxo começa no POST SAP; próximo contrato informado 1106. Nenhum evento real carregado nesta sessão.\r\nContrato SOAP e protocolo REST em etapas distintas, com reserva durável antes de envio.\r\nCadastros e consultas reais desabilitados nesta sessão. Runtime/journal PostgreSQL não atestados.\r\nNenhum worker/timer iniciado.";
            return;
        }
        LblResumoConteudo.Text="Telas liberadas para teste.\r\n\r\nSAP: consulta manual do BP 20000014 pelo perfil efetivo.\r\nGuardian: consultar o status e o binding manual na tela de Cadastros.\r\n"+(File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.preview.R55.json"))?"ACM: contrato mestre SOAP e agendamento REST em prévias separadas; nenhum envio.":File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.preview.R53.json"))?"ACM: prévia REST local; PostgreSQL separado, sem consulta de banco.":"ACM: leitura de banco bloqueada.")+"\r\n\r\nWorkers, timers e escritas automáticas desabilitados.";
    }

    private void BtnSair_Click(object? sender, EventArgs e)
    {
        Close();
    }

    private void SelecionarBotaoMenu(Button botaoSelecionado)
    {
        foreach (var botao in PnlMenuLateral.Controls.OfType<Button>())
        {
            botao.BackColor = botao == botaoSelecionado ? corMenuAtivo : corMenuPadrao;
        }
    }
}
