using FugaTES.Aplicacao.Consultas.Monitor;
using FugaTES.WinForms.Monitor;

namespace FugaTES.WinForms;

public partial class FrmMonitorMvp : Form, IMonitorView
{
    private readonly MonitorPresenter presenter;
    private readonly CancellationTokenSource closed = new();
    private readonly IDisposable? lifetime;
    private bool binding;
    private string grupo = "TODOS";
    private Guid? SelectedId => Integracoes.CurrentRow?.DataBoundItem is MonitorIntegracao row ? row.IntegracaoId : null;

    public FrmMonitorMvp() : this(new MonitorOperacionalConsulta(new DesignerRepository()), "Nao informado") { }

    public FrmMonitorMvp(MonitorOperacionalConsulta consulta, string ambiente, IDisposable? lifetime = null)
    {
        InitializeComponent();
        this.lifetime = lifetime;
        Ambiente.Text = "Ambiente: " + MonitorOperacionalConsulta.TextoSeguro(ambiente);
        presenter = new(consulta, this);
        Shown += async (_, _) => { RefreshTimer.Start(); await AtualizarAsync(); };
        FormClosed += (_, _) => { RefreshTimer.Stop(); closed.Cancel(); };
        Atualizar.Click += async (_, _) => await AtualizarAsync();
        RefreshTimer.Tick += async (_, _) => { if (AutoRefresh.Checked) await AtualizarAsync(); };
        Integracoes.SelectionChanged += async (_, _) =>
        {
            if (binding || closed.IsCancellationRequested) return;
            LimparDetalhe();
            MostrarGeral();
            if (SelectedId is Guid id) await presenter.DetalharAsync(id, closed.Token);
        };
        Todos.Click += async (_, _) => { grupo = "TODOS"; await AtualizarAsync(); };
        Pendentes.Click += async (_, _) => { grupo = "PENDENTES"; await AtualizarAsync(); };
        Falhas.Click += async (_, _) => { grupo = "FALHAS"; await AtualizarAsync(); };
        Indeterminados.Click += async (_, _) => { grupo = "INDETERMINADOS"; await AtualizarAsync(); };
    }

    private async Task AtualizarAsync()
    {
        if (closed.IsCancellationRequested) return;
        DateTimeOffset? de = De.Checked ? new DateTimeOffset(De.Value.Date) : null;
        DateTimeOffset? ate = Ate.Checked ? new DateTimeOffset(Ate.Value.Date.AddDays(1).AddTicks(-1)) : null;
        await presenter.AtualizarAsync(new(Operacao.Text, Estado.Text, Correlacao.Text, Documento.Text, de, ate, grupo), SelectedId, closed.Token);
    }

    public void Mostrar(MonitorSnapshot snapshot)
    {
        if (closed.IsCancellationRequested || IsDisposed) return;
        var id = SelectedId;
        binding = true;
        try
        {
            Integracoes.DataSource = snapshot.Integracoes.ToList();
            foreach (DataGridViewRow row in Integracoes.Rows)
                if (row.DataBoundItem is MonitorIntegracao item && item.IntegracaoId == id)
                    Integracoes.CurrentCell = row.Cells[0];
            foreach (DataGridViewColumn column in Integracoes.Columns)
            {
                if (new[] { "Fluxo", "StatusFuncional", "EtapaFuncional", "DecisaoPendente", "SalesOrder", "DeliveryDocument", "PurchaseOrder", "MaterialDocument", "MaterialDocumentYear", "NumeroTicketGuardian" }.Contains(column.Name))
                    column.Visible = snapshot.ProjecaoDisponivel;
                if (column.Name is "CriadoEm" or "AtualizadoEm") column.DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss";
            }
            var ordem = new[] { "CriadoEm", "Operacao", "CorrelationId", "IntegracaoId" };
            for (var index = 0; index < ordem.Length; index++)
                if (Integracoes.Columns[ordem[index]] is { } column) column.DisplayIndex = index;
            Projecao.Text = snapshot.ProjecaoDisponivel ? "Projecao MVP instalada" : "Projeção MVP ainda não instalada";
            Banco.Text = "Banco conectado";
            UltimoRefresh.Text = "Ultimo refresh: " + DateTime.Now.ToString("HH:mm:ss");
            Indicadores.Text = string.Join("    |    ", MonitorOperacionalConsulta.Contadores(snapshot.Integracoes).Select(c => c.Key + ": " + c.Value));
            Escopo.Text = "Integracoes recentes: " + snapshot.Integracoes.Count + " / limite 500 - " + grupo;
            LimparDetalhe(); MostrarGeral();
        }
        finally { binding = false; }
    }

    public void MostrarDetalhe(Guid id, MonitorDetalhe detalhe)
    {
        if (SelectedId != id || closed.IsCancellationRequested || IsDisposed) return;
        Tentativas.DataSource = detalhe.Tentativas.ToList(); Auditoria.DataSource = detalhe.Auditoria.ToList();
        Guardian.DataSource = detalhe.Guardian.ToList();
    }

    public void MostrarFalha()
    {
        Banco.Text = "Banco desconectado / consulta indisponivel";
        Projecao.Text = "Projecao MVP: nao verificada";
        binding = true; Integracoes.DataSource = null; binding = false;
        Indicadores.Text = "Indicadores indisponiveis"; LimparDetalhe();
    }

    private void MostrarGeral()
    {
        if (Integracoes.CurrentRow?.DataBoundItem is not MonitorIntegracao row) { Geral.Text = ""; return; }
        Geral.Text = $"IntegrationId: {row.IntegracaoId}\r\nCorrelationId: {row.CorrelationId}\r\nOperacao: {row.Operacao}\r\nEstado: {row.EstadoMotor}\r\nTentativa atual: {row.Tentativa}\r\nResultado: {row.UltimoResultado}\r\nProtocolo Guardian: {row.ProtocoloGuardian}\r\nTicket callback: {row.TicketGuardian}\r\nNumeroTicket resposta: {row.NumeroTicketGuardian}";
    }

    private void LimparDetalhe() { Geral.Clear(); Tentativas.DataSource = null; Auditoria.DataSource = null; Guardian.DataSource = null; }

    private sealed class DesignerRepository : IMonitorReadRepository
    {
        public Task<MonitorSnapshot> ConsultarAsync(MonitorFiltro filtro, CancellationToken ct) => throw new InvalidOperationException();
        public Task<MonitorDetalhe> DetalharAsync(Guid id, CancellationToken ct) => throw new InvalidOperationException();
    }
}
