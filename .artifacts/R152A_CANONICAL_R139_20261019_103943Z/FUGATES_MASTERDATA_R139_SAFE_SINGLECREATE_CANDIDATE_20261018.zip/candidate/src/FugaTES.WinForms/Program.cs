using System.Security.Principal;
using FugaTES.WinForms.Runtime;

namespace FugaTES.WinForms;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        using var instance = new Mutex(false, (Transportadoras.SafeDemoReadOnlySessionR50.Enabled?(File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.execution.R57.json"))?"Local\\FugaTES.SafeDemo.R57.":File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.preview.R55.json"))?"Local\\FugaTES.SafeDemo.R55.":File.Exists(Path.Combine(AppContext.BaseDirectory,"Acm.preview.R53.json"))?"Local\\FugaTES.SafeDemo.R53.":File.Exists(Path.Combine(AppContext.BaseDirectory,"Guardian.read.R50B.json"))?"Local\\FugaTES.SafeDemo.R50B.":"Local\\FugaTES.SafeDemo.R50."):"Local\\FugaTES.Desktop.") + WindowsIdentity.GetCurrent().User!.Value);
        var acquired = false;
        try
        {
            try { acquired = instance.WaitOne(0); }
            catch (AbandonedMutexException) { acquired = true; }
            if (!acquired) { MessageBox.Show("FugaTES já está aberto.", "FugaTES", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            if(Transportadoras.SafeDemoReadOnlySessionR50.Enabled)
            {
                using var demo=Transportadoras.SafeDemoReadOnlySessionR50.Create(AppContext.BaseDirectory);
                Application.Run(new PainelInicialForm(demo:demo));return;
            }
            DesktopRuntime.Initialize();
            var carrier=Transportadoras.CarrierDesktopComposition.Create();
            try { Application.Run(new PainelInicialForm(carrier)); }
            finally { carrier.StopAsync().GetAwaiter().GetResult(); }
        }
        finally
        {
            DesktopRuntime.Current?.Dispose();
            if (acquired) instance.ReleaseMutex();
        }
    }
}