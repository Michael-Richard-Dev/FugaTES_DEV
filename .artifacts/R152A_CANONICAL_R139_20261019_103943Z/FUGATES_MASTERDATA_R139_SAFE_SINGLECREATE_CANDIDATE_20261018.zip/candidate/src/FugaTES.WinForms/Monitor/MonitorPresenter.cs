using FugaTES.Aplicacao.Consultas.Monitor;

namespace FugaTES.WinForms.Monitor;

public interface IMonitorView
{
    void Mostrar(MonitorSnapshot snapshot);
    void MostrarDetalhe(Guid id, MonitorDetalhe detalhe);
    void MostrarFalha();
}

public sealed class MonitorPresenter(MonitorOperacionalConsulta consulta, IMonitorView view)
{
    private readonly SemaphoreSlim gate = new(1, 1);
    public async Task<bool> AtualizarAsync(MonitorFiltro filtro, Guid? selectedId, CancellationToken ct)
    {
        if (!await gate.WaitAsync(0, ct)) return false;
        try
        {
            var snapshot = await consulta.ConsultarAsync(filtro, ct);
            var id = selectedId is Guid selected && snapshot.Integracoes.Any(i => i.IntegracaoId == selected)
                ? selectedId : snapshot.Integracoes.FirstOrDefault()?.IntegracaoId;
            MonitorDetalhe? detail = id is Guid detailId ? await consulta.DetalharAsync(detailId, ct) : null;
            ct.ThrowIfCancellationRequested();
            view.Mostrar(snapshot);
            if (detail is not null) view.MostrarDetalhe(id!.Value, detail);
            return true;
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { return false; }
        catch { if (!ct.IsCancellationRequested) view.MostrarFalha(); return false; }
        finally { gate.Release(); }
    }

    public async Task DetalharAsync(Guid id, CancellationToken ct)
    {
        if (!await gate.WaitAsync(0, ct)) return;
        try
        {
            var detail = await consulta.DetalharAsync(id, ct);
            ct.ThrowIfCancellationRequested(); view.MostrarDetalhe(id, detail);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { }
        catch { if (!ct.IsCancellationRequested) view.MostrarFalha(); }
        finally { gate.Release(); }
    }
}
