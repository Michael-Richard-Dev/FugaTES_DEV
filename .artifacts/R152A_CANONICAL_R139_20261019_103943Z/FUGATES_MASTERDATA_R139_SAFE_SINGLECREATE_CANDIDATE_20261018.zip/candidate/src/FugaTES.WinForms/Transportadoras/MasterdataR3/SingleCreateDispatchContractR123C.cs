﻿using FugaTES.Aplicacao.Transportadoras;
namespace FugaTES.WinForms.Transportadoras.MasterdataR3;

// R123C: contrato que liga o botao unitario -> journal duravel -> dispatch.
// NAO e uma implementacao paralela de cadastro: o despacho real continua sendo
// GuardianSingleCreateUseCaseR31, composto por SingleCreateDesktopBindingR41. Esta classe apenas
// ordena e comprova as pre-condicoes ANTES de qualquer POST, e fica fail-closed por construcao:
// toda dependencia nao fornecida (delegate nulo) bloqueia.
public enum EtapaDispatchR123C
{
    Prontidao,
    JournalFisico,
    CreatePendente,
    AusenciaGuardianEscopada,
    AutorizacaoPost,
    LiberadoParaDespacho
}

public sealed record PreDispatchR123C(bool Liberado, EtapaDispatchR123C ParouEm, string Codigo)
{
    public static PreDispatchR123C Bloqueio(EtapaDispatchR123C etapa, string codigo) => new(false, etapa, codigo);
}

// Dependencias do pre-dispatch. Qualquer uma ausente bloqueia a etapa correspondente.
public sealed record PreDispatchDependenciasR123C
{
    // Comprova a tabela do journal no runtime de escrita efetivo (nao a implementacao offline).
    public Func<CancellationToken, Task<bool>>? JournalFisicoDisponivel { get; init; }

    // Comprova ausencia de tentativa anterior pendente/confirmada para este BP/codigo.
    public Func<CancellationToken, Task<bool>>? SemCreatePendente { get; init; }

    // Nova consulta Guardian ESCOPADA, imediatamente antes do POST. Executada no maximo uma vez.
    public Func<CancellationToken, Task<CarrierManualGuardian>>? ConsultaEscopada { get; init; }

    // Autorizacao especifica de POST concedida pela Hera para esta tentativa.
    public Func<bool>? AutorizacaoPost { get; init; }
}

public static class SingleCreateDispatchContractR123C
{
    // Ordem obrigatoria. Para na primeira pre-condicao nao satisfeita e devolve a etapa exata.
    // A consulta escopada e feita UMA vez; resultado indeterminado bloqueia e NAO e repetido aqui.
    public static async Task<PreDispatchR123C> VerificarAsync(
        ProntidaoSingleCreateR122? prontidao,
        PreDispatchDependenciasR123C? dependencias,
        CancellationToken ct)
    {
        if (prontidao is null || !prontidao.Pronto)
            return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.Prontidao,
                prontidao?.Resumo ?? "SINGLE_CREATE_READINESS_ABSENT");

        var deps = dependencias ?? new PreDispatchDependenciasR123C();

        if (ct.IsCancellationRequested)
            return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.Prontidao, "SINGLE_CREATE_CANCELLED");

        // 1) Journal fisico no runtime de escrita.
        if (deps.JournalFisicoDisponivel is null)
            return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.JournalFisico, "SINGLE_CREATE_JOURNAL_RUNTIME_NOT_ATTESTED");
        try
        {
            if (!await deps.JournalFisicoDisponivel(ct).ConfigureAwait(false))
                return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.JournalFisico, "SINGLE_CREATE_JOURNAL_MIGRATION_PENDING_GAIA");
        }
        catch { return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.JournalFisico, "SINGLE_CREATE_JOURNAL_PREFLIGHT_FAILED"); }

        // 2) Nenhuma tentativa anterior pendente ou confirmada.
        if (deps.SemCreatePendente is null)
            return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.CreatePendente, "PENDING_OR_REPLAY_CHECK_NOT_AVAILABLE");
        try
        {
            if (!await deps.SemCreatePendente(ct).ConfigureAwait(false))
                return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.CreatePendente, "PENDING_OR_REPLAY_RECONCILIATION_REQUIRED");
        }
        catch { return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.CreatePendente, "PENDING_CHECK_OUTCOME_UNKNOWN"); }

        // 3) Nova consulta escopada: so uma ausencia comprovada por 404 escopado libera.
        if (deps.ConsultaEscopada is null)
            return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.AusenciaGuardianEscopada, "GUARDIAN_SCOPED_RECHECK_NOT_AVAILABLE");
        CarrierManualGuardian observado;
        try { observado = await deps.ConsultaEscopada(ct).ConfigureAwait(false); }
        catch { return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.AusenciaGuardianEscopada, "GUARDIAN_SCOPED_RECHECK_FAILED"); }
        if (observado.State != CarrierLookupState.Absent || !observado.Ausencia404Comprovada)
            return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.AusenciaGuardianEscopada, "GUARDIAN_CREATE_ABSENCE_NOT_PROVEN");

        // 4) Autorizacao especifica de POST, reavaliada depois das consultas.
        bool autorizado;
        try { autorizado = deps.AutorizacaoPost?.Invoke() == true; }
        catch { autorizado = false; }
        if (!autorizado)
            return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.AutorizacaoPost, "SINGLE_CREATE_DISPATCH_NOT_AUTHORIZED");

        if (ct.IsCancellationRequested)
            return PreDispatchR123C.Bloqueio(EtapaDispatchR123C.AutorizacaoPost, "SINGLE_CREATE_CANCELLED");

        // Liberado apenas para o despacho do R31. Nenhum POST ocorre nesta classe.
        return new(true, EtapaDispatchR123C.LiberadoParaDespacho, "SINGLE_CREATE_PRE_DISPATCH_OK");
    }
}
