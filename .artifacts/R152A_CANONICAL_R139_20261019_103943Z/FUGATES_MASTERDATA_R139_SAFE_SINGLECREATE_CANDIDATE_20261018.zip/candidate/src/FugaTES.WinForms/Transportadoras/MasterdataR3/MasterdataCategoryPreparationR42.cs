﻿namespace FugaTES.WinForms.Transportadoras.MasterdataR3;

// Preparacao das categorias de masterdata ainda nao entregues (Emissores, Materiais, Motoristas,
// Veiculos). Registra a categoria no orquestrador compartilhado SEM habilitar sincronizacao.
//
// Porque bloqueado e nao CREATE-only: Emissor e Item possuem apenas POST de criacao comprovado no
// cliente Guardian. Sem GET comprovado nao existe comparacao, UPDATE nem NO_ACTION, e um ciclo
// CREATE-only reaplicado criaria duplicidade. Enquanto o contrato de reconciliacao nao for
// comprovado, a categoria permanece bloqueada por construcao: o orquestrador nao invoca a acao
// quando ContratoHomologado ou CheckpointDuravelDisponivel sao falsos.
//
// Motoristas e Veiculos nao tem fonte SAP nem rota Guardian comprovadas e por isso nao recebem
// nenhuma equivalencia presumida com BP.
public enum PreparoCategoriaMasterdataR42 { ReconciliacaoNaoComprovada, FonteNaoComprovada, FonteEApiNaoComprovadas }

public sealed record PreparoMasterdataR42(CategoriaMasterdataR3 Categoria, PreparoCategoriaMasterdataR42 Situacao, string Motivo)
{
    // Sempre falso neste estagio: nenhuma das categorias preparadas tem contrato de reconciliacao
    // comprovado. O campo existe para que a liberacao futura seja uma mudanca de dado, nao de forma.
    public bool ContratoHomologado => false;
    public bool CheckpointDuravelDisponivel => false;

    public AcaoCategoriaDelegadaMasterdataR3 ParaAcao() => new(Categoria, ContratoHomologado, CheckpointDuravelDisponivel,
        _ => Task.FromResult(new ResultadoCategoriaMasterdataR3(EstadoMasterdataR3.Bloqueado, 0, 0, 0, 0, null, false)));

    public override string ToString() => Motivo;
}

public static class MasterdataCategoryPreparationR42
{
    public const string EmissorBlocker = "EMISSOR_RECONCILIATION_CONTRACT_NOT_PROVEN";
    public const string MaterialBlocker = "MATERIAL_RECONCILIATION_CONTRACT_NOT_PROVEN";
    public const string MotoristaBlocker = "MOTORISTA_SAP_SOURCE_NOT_PROVEN";
    public const string VeiculoBlocker = "VEICULO_SOURCE_AND_API_NOT_PROVEN";

    // FASE B: preparadas, com fonte SAP de leitura existente e POST Guardian comprovado,
    // faltando exclusivamente o contrato de GET/reconciliacao que torna o ciclo idempotente.
    public static PreparoMasterdataR42 Emissores { get; } =
        new(CategoriaMasterdataR3.Emissores, PreparoCategoriaMasterdataR42.ReconciliacaoNaoComprovada, EmissorBlocker);
    public static PreparoMasterdataR42 Materiais { get; } =
        new(CategoriaMasterdataR3.Materiais, PreparoCategoriaMasterdataR42.ReconciliacaoNaoComprovada, MaterialBlocker);

    // FASE C: mantidas desabilitadas enquanto as fontes nao estiverem comprovadas.
    public static PreparoMasterdataR42 Motoristas { get; } =
        new(CategoriaMasterdataR3.Motoristas, PreparoCategoriaMasterdataR42.FonteNaoComprovada, MotoristaBlocker);
    public static PreparoMasterdataR42 Veiculos { get; } =
        new(CategoriaMasterdataR3.Veiculos, PreparoCategoriaMasterdataR42.FonteEApiNaoComprovadas, VeiculoBlocker);

    public static IReadOnlyList<PreparoMasterdataR42> FaseB { get; } = [Emissores, Materiais];
    public static IReadOnlyList<PreparoMasterdataR42> FaseC { get; } = [Motoristas, Veiculos];
    public static IReadOnlyList<PreparoMasterdataR42> Todas { get; } = [Emissores, Materiais, Motoristas, Veiculos];

    // Acoes prontas para somar as ja registradas (Transportadoras permanece intocada).
    // Registrar estas categorias nao habilita escrita: o orquestrador as pula fail-closed.
    public static IReadOnlyList<AcaoCategoriaDelegadaMasterdataR3> Acoes() => [.. Todas.Select(p => p.ParaAcao())];
}
