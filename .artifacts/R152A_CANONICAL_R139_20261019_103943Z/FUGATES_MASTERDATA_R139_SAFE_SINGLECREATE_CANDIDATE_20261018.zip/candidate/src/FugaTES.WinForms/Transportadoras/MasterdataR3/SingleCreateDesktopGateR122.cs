﻿using System.Globalization;
using System.Security.Principal;
using FugaTES.HostIntegracao;
using FugaTES.WinForms.Runtime;
using Microsoft.Extensions.Configuration;
namespace FugaTES.WinForms.Transportadoras.MasterdataR3;

// R122: avaliacao de PRONTIDAO do CREATE unitario de transportadora.
// Puramente local: nao abre conexao, nao consulta SAP, Guardian ou banco. Serve para decidir se o
// botao de CREATE pode sequer ficar habilitado, e para mostrar ao operador exatamente o que falta.
//
// Nenhuma condicao nova de negocio e inventada aqui: cada item ja era exigido por
// GuardianSingleCreateUseCaseR31, GuardianSingleCreatePreparationR41, GuardianCarrierCreateBodyR37
// ou SingleCreateDesktopBindingR41. Esta classe apenas os antecipa, fail-closed.
public sealed record ProntidaoSingleCreateR122(bool Pronto, IReadOnlyList<string> Bloqueios)
{
    public string Resumo => Pronto
        ? "SINGLE_CREATE_PRONTO_AGUARDANDO_AUTORIZACAO_DE_DISPATCH"
        : string.Join(" | ", Bloqueios);
}

public static class SingleCreateDesktopGateR122
{
    public const string PerfilCarrier = "FugaTES.carrier.json";

    // Chave do callback HML do cadastro de Transportadora. Deliberadamente SEM valor padrao:
    // o callback do ACM/Set26 nao e equivalente e nao pode ser assumido.
    public const string ChaveCallback = "Carrier:SingleCreate:CallbackUrl";
    public const string ChaveCallbackAprovado = "Carrier:SingleCreate:CallbackApproved";
    public const string ChaveHabilitado = "Carrier:SingleCreate:Enabled";

    // Reconciliacao do POST historico citado no R120: enquanto nao for comprovada, um cadastro
    // anterior nao reconciliado permanece possivel e o CREATE fica bloqueado.
    public const string ChaveHistoricoReconciliado = "Carrier:SingleCreate:HistoricalPostReconciled";

    public static ProntidaoSingleCreateR122 Avaliar(string bp, DateTimeOffset agora, string? sid = null,
        IConfiguration? config = null, bool? journalFisicoComprovado = null)
    {
        var bloqueios = new List<string>();
        try { CarrierPersistencePolicyProxy(bp); }
        catch { return new(false, ["SINGLE_CREATE_BP_INVALIDO"]); }

        if (config is null)
        {
            try { config = CarrierDesktopProfile.Load(Path.Combine(AppContext.BaseDirectory, PerfilCarrier)); }
            catch (DesktopStartupException erro) { return new(false, [erro.Code]); }
            catch { return new(false, ["SINGLE_CREATE_PERFIL_INVALIDO"]); }
        }

        if (!CarrierDesktopProfile.True(config, ChaveHabilitado)) bloqueios.Add("SINGLE_CREATE_DESKTOP_DISABLED");
        if (config["Carrier:Environment"] != "HML") bloqueios.Add("CARRIER_DESKTOP_HML_NOT_PROVEN");

        // CREATE exige o contrato COMPLETO (rota de escrita e codec de resposta), nao so o manual.
        if (CarrierProtocolBinding.BuildGuardianContract(config) is null)
            bloqueios.Add("CARRIER_DESKTOP_GUARDIAN_HML_NOT_PROVEN");

        // Callback HML do cadastro de Transportadora: valor aprovado, https absoluta, sem userinfo/fragmento.
        var callback = config[ChaveCallback];
        if (!CarrierDesktopProfile.True(config, ChaveCallbackAprovado) || string.IsNullOrWhiteSpace(callback) ||
            !Uri.TryCreate(callback, UriKind.Absolute, out var destino) || destino.Scheme != Uri.UriSchemeHttps ||
            destino.UserInfo.Length != 0 || destino.Fragment.Length != 0)
            bloqueios.Add("CREATE_CALLBACK_HML_NOT_APPROVED");

        // Vinculo de identidade do BP (codigo Guardian + idAssinatura do escopo GET + aprovacao).
        if (CarrierManualReadOnlyProfile.Identity(config, bp) is null)
            bloqueios.Add("GUARDIAN_BP_CODE_BINDING_NOT_PROVEN");

        // Janela, BP e SID autorizados.
        if (!DateTimeOffset.TryParse(config["Carrier:Authorization:UntilUtc"], CultureInfo.InvariantCulture,
                DateTimeStyles.None, out var ate) || agora >= ate)
            bloqueios.Add("SINGLE_CREATE_AUTHORIZATION_EXPIRED");
        if (!Valores(config, "Carrier:Authorization:AllowedBps").Contains(bp, StringComparer.Ordinal))
            bloqueios.Add("SINGLE_CREATE_BP_NOT_AUTHORIZED");
        sid ??= SidAtual();
        if (string.IsNullOrWhiteSpace(sid) || !Valores(config, "Carrier:Authorization:AllowedSids").Contains(sid, StringComparer.Ordinal))
            bloqueios.Add("SINGLE_CREATE_SID_NOT_AUTHORIZED");

        // POST historico (R120) ainda nao reconciliado.
        if (!CarrierDesktopProfile.True(config, ChaveHistoricoReconciliado))
            bloqueios.Add("HISTORICAL_POST_NOT_RECONCILED");

        // Journal fisico: quem avalia precisa comprovar. Ausencia de comprovacao bloqueia.
        if (journalFisicoComprovado != true) bloqueios.Add("SINGLE_CREATE_JOURNAL_RUNTIME_NOT_ATTESTED");

        // Sincronizacao automatica tem de continuar desabilitada mesmo com CREATE liberado.
        foreach (var chave in new[] { "FUGATES_INTEGRATION_WORKER_ENABLED", "INC005_WORKER_ENABLED", "Carrier:IntegrationWorkerEnabled" })
            if (bool.TryParse(config[chave], out var ligada) && ligada) bloqueios.Add("AUTOMATIC_SYNC_MUST_REMAIN_DISABLED");

        return new(bloqueios.Count == 0, bloqueios);
    }

    private static void CarrierPersistencePolicyProxy(string bp)
        => FugaTES.Aplicacao.Transportadoras.CarrierPersistencePolicy.ValidateBp(bp);

    private static string? SidAtual()
    {
        try { return OperatingSystem.IsWindows() ? WindowsIdentity.GetCurrent().User?.Value : null; }
        catch { return null; }
    }

    private static string[] Valores(IConfiguration config, string chave)
        => config.GetSection(chave).GetChildren().Select(c => c.Value).Where(v => v is not null).Cast<string>().ToArray();
}
