﻿using FugaTES.Aplicacao.Transportadoras.SingleCreateR31;
namespace FugaTES.Persistencia.Transportadoras.Fakes;

// DUPLO DE TESTE/STAGING. NAO e caminho de escrita de producao: nada e persistido e todo o estado
// morre com o processo. Existe para provar offline a semantica de reserva, replay, concorrencia e
// confirmacao usando a MESMA SingleCreateJournalPolicyR31 do adapter PostgreSQL.
// Nao registrar em composicao de runtime: o preflight de HML exige o journal durable.
public sealed class SingleCreateJournalMemoryFakeR31(TimeProvider? clock = null) : ISingleCreateJournalR31
{
    public sealed record EntryR31(Guid AttemptId, string Bp, string GuardianCode, string PayloadHash, string Status,
        DateTimeOffset PreparedUtc, DateTimeOffset? ConfirmedUtc);

    private readonly object gate = new();
    private readonly Dictionary<Guid, EntryR31> entries = [];

    public IReadOnlyCollection<EntryR31> Entries { get { lock (gate) return entries.Values.ToArray(); } }

    public Task<bool> TryPrepareAsync(Guid attemptId, string bp, string code, string payloadHash, CancellationToken ct)
    {
        SingleCreateJournalPolicyR31.ValidateEntry(attemptId, bp, code, payloadHash);
        lock (gate)
        {
            // Equivalente em memoria do predicado e dos indices unicos do adapter: qualquer linha
            // previa para este bp, este codigo ou este attempt rejeita a reserva.
            var occupied = entries.ContainsKey(attemptId) || entries.Values.Any(e => e.Bp == bp || e.GuardianCode == code);
            if (occupied) return Task.FromResult(false);
            entries[attemptId] = new(attemptId, bp, code, payloadHash, SingleCreateJournalPolicyR31.PreparedStatus,
                (clock ?? TimeProvider.System).GetUtcNow().ToUniversalTime(), null);
            return Task.FromResult(true);
        }
    }

    public Task ConfirmAsync(Guid attemptId, CancellationToken ct)
    {
        if (attemptId == Guid.Empty) throw new ArgumentException("SINGLE_CREATE_JOURNAL_ATTEMPT_INVALID");
        lock (gate)
        {
            var found = entries.TryGetValue(attemptId, out var entry);
            var affected = found && entry!.Status == SingleCreateJournalPolicyR31.PreparedStatus ? 1 : 0;
            if (affected == 1)
                entries[attemptId] = entry! with
                {
                    Status = SingleCreateJournalPolicyR31.ConfirmedStatus,
                    ConfirmedUtc = (clock ?? TimeProvider.System).GetUtcNow().ToUniversalTime()
                };
            if (!SingleCreateJournalPolicyR31.ConfirmSatisfied(affected, found ? entries[attemptId].Status : null))
                throw new InvalidOperationException("SINGLE_CREATE_JOURNAL_CONFIRM_NOT_PERSISTED");
            return Task.CompletedTask;
        }
    }
}
