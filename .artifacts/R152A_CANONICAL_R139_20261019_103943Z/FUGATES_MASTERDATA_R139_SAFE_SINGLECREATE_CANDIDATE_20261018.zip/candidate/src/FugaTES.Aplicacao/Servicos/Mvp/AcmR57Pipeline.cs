using FugaTES.Aplicacao.Contratos.ContratosSapToledo;
using FugaTES.Aplicacao.Contratos.Guardian;
using FugaTES.Aplicacao.Contratos.Mvp;
using FugaTES.Aplicacao.Modelos.MotorIntegracao;
using FugaTES.Aplicacao.Modelos.Mvp;
using FugaTES.Aplicacao.Servicos.ContratosSapToledo;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Globalization;
namespace FugaTES.Aplicacao.Servicos.Mvp;

public sealed class AcmR57Pipeline(IContratoSapToledoVersaoStore contratos,IAcmR57Preparacao preparacao,
    IAcmR57RuntimeGate gate,IGuardianContratoSincronizacaoGateway soap,IAcmPreCadastroMinimoGatewayR57 rest,
    IResultadoFluxoMvpStore journal,IAcmGuardianVinculoStore vinculos)
{
    public async Task<ResultadoFluxoMvp> ExecutarAsync(ClaimIntegracaoMotor claim,CancellationToken ct,Action? antesEscrita=null)
    {
        ct.ThrowIfCancellationRequested();
        ResultadoFluxoMvp Block(string code)=>new(StatusFluxoMvp.AguardandoDependenciaExterna,claim.CorrelationId,"R57_PRE_SEND_BLOCKED",Erro:code,ErroReprocessavel:false);
        var version=await contratos.ObterPorIntegracaoIdAsync(claim.IntegracaoId,ct);
        if(version is null || claim.Operacao!="SAP_CONTRATO_TOLEDO" || claim.Origem!="SAP" || claim.Destino!="TOLEDO" ||
            version.NumeroContrato!=claim.ChaveNegocio || version.FingerprintSha256!=claim.FingerprintSha256 || claim.FencingToken<=0 ||
            new ContratoSapToledoCanonicalizer().Canonicalizar(version.Snapshot).FingerprintSha256!=version.FingerprintSha256)
            return Block("R57_INBOUND_IDENTITY_INVALID");
        ResultadoFluxoMvp? previous;
        try{await journal.ExigirDisponibilidadeAsync(ct);previous=await journal.ObterAsync(claim,ct);}
        catch(OperationCanceledException) when(ct.IsCancellationRequested){throw;}
        catch{return Block("R57_DURABLE_JOURNAL_UNAVAILABLE");}
        if(previous?.Status is StatusFluxoMvp.AguardandoCallback or StatusFluxoMvp.Concluido or StatusFluxoMvp.FalhaNaoReprocessavel or StatusFluxoMvp.ResultadoIndeterminado)
            return previous;
        // Only a persisted pre-dispatch block may be retried safely; an armed or unknown stage never is.
        var initialStage=previous?.Etapa;
        if(previous is null && claim.FencingToken>1)
            return new(StatusFluxoMvp.ResultadoIndeterminado,claim.CorrelationId,"R57_REPLAY_UNPROVEN",Erro:"R57_DURABLE_REPLAY_RESULT_MISSING");
        if(previous is not null && initialStage is not ("R57_PRE_SEND_BLOCKED" or "R57_SOAP_CONFIRMED"))
            return new(StatusFluxoMvp.ResultadoIndeterminado,claim.CorrelationId,"R57_REPLAY_UNPROVEN",Erro:"R57_DURABLE_STAGE_UNPROVEN");
        async Task<ResultadoFluxoMvp> PreBlock(string code)
        {
            var blocked=Block(code).Normalizar();
            if(initialStage is null or "R57_PRE_SEND_BLOCKED")
            {
                if(await journal.ReservarEtapaAsync(claim,initialStage,blocked,ct))return blocked;
                // A concurrent dispatcher may have armed the stage. Never overwrite its durable marker.
                return await journal.ObterAsync(claim,ct) ?? blocked;
            }
            return blocked;
        }
        var runtimeBlock=gate.Bloqueio(version);
        if(runtimeBlock is not null)return await PreBlock(runtimeBlock);
        if(await contratos.TemPredecessorNaoTerminalAsync(version.NumeroContrato,version.Versao,ct))return await PreBlock("R57_PREDECESSOR_PENDING");
        AcmR57Plano plan;
        try{plan=AcmR57Mapping.Criar(version,preparacao.Obter(version));}
        catch(AcmR57BlockedException ex){return await PreBlock(ex.Code);}
        var digest=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(plan))));
        string Metadata(long? sequence)=>"R57:"+(sequence?.ToString(CultureInfo.InvariantCulture)??"")+":"+digest;
        ResultadoFluxoMvp State(StatusFluxoMvp status,string step,long? sequence=null,string? code=null,ProtocoloAcmR57? protocol=null)
            =>new(status,claim.CorrelationId,step,ResultadoFuncional:Metadata(sequence),Erro:code,
                ProtocoloGuardian:protocol?.Id.ToString(CultureInfo.InvariantCulture),NumeroTicketGuardian:protocol?.NumeroTicket,
                ErroReprocessavel:code is null?null:false);
        var soapWasConfirmed=initialStage=="R57_SOAP_CONFIRMED";
        if(soapWasConfirmed && (previous!.ResultadoFuncional is null || !previous.ResultadoFuncional.EndsWith(":"+digest,StringComparison.Ordinal)))
            return Block("R57_REPLAY_MAPPING_CHANGED");
        AcmGuardianVinculo link;
        try{link=await vinculos.ReservarSolicitacaoUnicaAsync(version,plan.Protocolo.Dados.NumeroReferencia,plan.Contrato.Codigo,ct);}
        catch(OperationCanceledException) when(ct.IsCancellationRequested){throw;}
        catch{return await PreBlock("R57_DURABLE_REFERENCE_RESERVATION_FAILED");}
        if(link.IntegracaoIdOrigem!=version.IntegracaoId || link.NumeroContratoSap!=version.NumeroContrato || link.VersaoH4!=version.Versao ||
            link.NumeroReferenciaSolicitado!=plan.Protocolo.Dados.NumeroReferencia || link.CodigoContratoSolicitado!=plan.Contrato.Codigo)
            return await PreBlock("R57_DURABLE_LINK_IDENTITY_MISMATCH");
        long? sequence=null;
        if(soapWasConfirmed)
        {
            var parts=previous!.ResultadoFuncional?.Split(':');
            if(parts is null || parts.Length!=3 || parts[0]!="R57" || link.CodigoContratoConfirmado!=plan.Contrato.Codigo)
                return Block("R57_CONFIRMED_CONTRACT_UNPROVEN");
            if(parts[1].Length>0){if(!long.TryParse(parts[1],out var parsed)||parsed<=0)return Block("R57_CONTRACT_SEQUENCE_UNPROVEN");sequence=parsed;}
        }
        else
        {
            ConsultaContratoGuardian lookup;
            try{lookup=await soap.ConsultarAsync(plan.Contrato.Codigo,ct);}
            catch(OperationCanceledException) when(ct.IsCancellationRequested){throw;}
            catch{return await PreBlock("R57_SOAP_LOOKUP_UNPROVEN");}
            if(lookup.Estado==EstadoConsultaContratoGuardian.Existente)
            {
                if(lookup.Contrato is null || !SincronizarContratoGuardian.Identicos(lookup.Contrato,plan.Contrato))
                    return await PreBlock("R57_CONTRACT_RECONCILIATION_REQUIRED");
                sequence=lookup.SequencialContrato;
                if(sequence is <=0)return await PreBlock("R57_CONTRACT_SEQUENCE_UNPROVEN");
                if(!await journal.ReservarEtapaAsync(claim,initialStage,State(StatusFluxoMvp.EmProcessamento,"R57_SOAP_CONFIRMED",sequence).Normalizar(),ct))
                    return await journal.ObterAsync(claim,ct) ?? Block("R57_STAGE_ALREADY_RESERVED");
                try{await vinculos.RegistrarCodigoConfirmadoAsync(version.IntegracaoId,plan.Contrato.Codigo,ct);}
                catch{var unknown=State(StatusFluxoMvp.ResultadoIndeterminado,"R57_SOAP_UNCONFIRMED",sequence,"R57_CONTRACT_IDENTITY_NOT_PERSISTED").Normalizar();await Save(unknown);return unknown;}
            }
            else
            {
                // User-attested manual registration: 1031 must only be reconciled, never created again.
                if(plan.Contrato.Codigo.TrimStart('0')=="1031")return await PreBlock("R57_KNOWN_CREATED_CONTRACT_RECONCILIATION_REQUIRED");
                if(lookup.Estado!=EstadoConsultaContratoGuardian.InexistenteComprovado || lookup.Contrato is not null)
                    return await PreBlock("R57_SOAP_ABSENCE_UNPROVEN");
                ct.ThrowIfCancellationRequested();
                var armed=State(StatusFluxoMvp.ResultadoIndeterminado,"R57_SOAP_ARMED",code:"R57_SOAP_DISPATCH_OUTCOME_UNKNOWN").Normalizar();
                if(!await journal.ReservarEtapaAsync(claim,initialStage,armed,ct))return await journal.ObterAsync(claim,ct) ?? Block("R57_STAGE_ALREADY_RESERVED");
                antesEscrita?.Invoke();
                ResultadoContratoGuardianComResposta created;
                try{created=await soap.CadastrarComRespostaAsync(plan.Contrato,ct);}
                catch(Exception ex) when(ex is IAcmGuardianBusinessFailure{BusinessErrorCode:not null and not 0})
                {
                    var failed=State(StatusFluxoMvp.FalhaNaoReprocessavel,"R57_SOAP_FAILED",code:"R57_SOAP_BUSINESS_REJECTED").Normalizar();
                    return await Save(failed)?failed:armed;
                }
                catch{return armed;}
                if(created.CodigoContratoConfirmado!=plan.Contrato.Codigo || created.SequencialContrato is <=0)return armed;
                sequence=created.SequencialContrato;
                try
                {
                    using var identityTimeout=new CancellationTokenSource(TimeSpan.FromSeconds(15));
                    await vinculos.RegistrarCodigoConfirmadoAsync(version.IntegracaoId,created.CodigoContratoConfirmado,identityTimeout.Token);
                    var confirmed=State(StatusFluxoMvp.EmProcessamento,"R57_SOAP_CONFIRMED",sequence).Normalizar();
                    if(!await Save(confirmed))return armed;
                }
                catch{return armed;}
            }
        }
        ct.ThrowIfCancellationRequested();
        var restArmed=State(StatusFluxoMvp.ResultadoIndeterminado,"R57_REST_ARMED",sequence,"R57_REST_DISPATCH_OUTCOME_UNKNOWN").Normalizar();
        if(!await journal.ReservarEtapaAsync(claim,"R57_SOAP_CONFIRMED",restArmed,ct))return await journal.ObterAsync(claim,ct) ?? Block("R57_STAGE_ALREADY_RESERVED");
        antesEscrita?.Invoke();
        try
        {
            var protocol=await rest.EnviarMinimoAcmAsync(plan.Protocolo,ct);
            if(!AcmR57Mapping.RespostaConfere(protocol,plan.Protocolo))return restArmed;
            using var identityTimeout=new CancellationTokenSource(TimeSpan.FromSeconds(15));
            await vinculos.RegistrarProtocoloConfirmadoAsync(version.IntegracaoId,protocol.Id,protocol.NumeroTicket,identityTimeout.Token);
            var confirmed=State(StatusFluxoMvp.AguardandoCallback,"R57_CONFIRMED",sequence,protocol:protocol).Normalizar();
            return await Save(confirmed)?confirmed:restArmed;
        }
        catch{return restArmed;}

        async Task<bool> Save(ResultadoFluxoMvp state)
        {
            using var bounded=new CancellationTokenSource(TimeSpan.FromSeconds(15));
            try{return await journal.PersistirAsync(claim,state,bounded.Token);}catch{return false;}
        }
    }
}
