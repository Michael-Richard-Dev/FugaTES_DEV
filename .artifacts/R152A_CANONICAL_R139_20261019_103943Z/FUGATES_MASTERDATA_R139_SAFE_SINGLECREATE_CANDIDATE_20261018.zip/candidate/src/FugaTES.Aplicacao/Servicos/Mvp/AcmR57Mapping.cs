using System.Globalization;
using System.Text.Json.Serialization;
using FugaTES.Aplicacao.Contratos.ContratosSapToledo;
using FugaTES.Aplicacao.Modelos.Guardian;

namespace FugaTES.Aplicacao.Servicos.Mvp;

public interface IAcmGuardianBusinessFailure { int? BusinessErrorCode { get; } }
public interface IAcmR57RuntimeGate { string? Bloqueio(VersaoContratoSapToledo versao); }
// A functional approval is not a runtime authorization. No permissive runtime implementation is registered.
public sealed class AcmR57RuntimeDisabled : IAcmR57RuntimeGate
{
    public string? Bloqueio(VersaoContratoSapToledo versao) => "R57_RUNTIME_WRITE_DISABLED";
}
public interface IAcmR57Preparacao { AcmR57Vinculos Obter(VersaoContratoSapToledo versao); }
public sealed class AcmR57PreparacaoPendente : IAcmR57Preparacao
{
    public AcmR57Vinculos Obter(VersaoContratoSapToledo versao) => throw new AcmR57BlockedException("R57_FUNCTIONAL_SOURCES_REQUIRED");
}
public sealed class AcmR57BlockedException(string code) : Exception(code) { public string Code { get; }=code; }

// Every value is scoped to the immutable inbound fingerprint, SAP item and centre.
// Sources are references, never credentials. No BP/material identity fallback.
public sealed record AcmR57Vinculos(string NumeroContratoSap,string ItemSap,string CentroSap,string FingerprintSap,
    string CodigoContratoGuardian,string EstadoGuardian,string TipoLancamentoGuardian,
    string SapBusinessPartner,string SapMaterial,string CodigoEmissorGuardian,string CodigoItemGuardian,
    string DocumentoOperacao,decimal PesoOrigem,string NumeroReferencia,string ValorCampoAdicional,
    string CallbackOperacional,string FonteMapeamentos,string FonteDocumento,string FontePeso,
    string FonteCampoAdicional,bool CallbackHomologado);

public sealed record DocumentoAcmR57(string Descricao,string PesoOrigem);
public sealed record DadosPreCadastroAcmR57(int Id,string CodigoItem,string CodigoEmissor,string CodigoContrato,
    IReadOnlyList<DocumentoAcmR57> Documentos,string NumeroReferencia,IReadOnlyList<CampoAdicionalGuardianSet26> CamposAdicionais);
public sealed record PreCadastroAcmR57(string Callback,DadosPreCadastroAcmR57 Dados);
public sealed record ProtocoloAcmR57(long Id,string CodigoContrato,string CodigoItem,string CodigoEmissor,
    string NumeroReferencia,string? NumeroTicket=null);
public interface IAcmPreCadastroMinimoGatewayR57
{
    Task<ProtocoloAcmR57> EnviarMinimoAcmAsync(PreCadastroAcmR57 comando,CancellationToken ct);
}
public sealed record AcmR57Plano(ContratoGuardianSet26 Contrato,PreCadastroAcmR57 Protocolo);

public static class AcmR57Mapping
{
    public static AcmR57Plano Criar(VersaoContratoSapToledo version,AcmR57Vinculos links)
    {
        var s=version.Snapshot;
        if(version.IntegracaoId==Guid.Empty || version.Versao<=0 || version.NumeroContrato!=s.NumeroContrato ||
            links.NumeroContratoSap!=s.NumeroContrato || links.ItemSap!=s.Item || links.CentroSap!=s.Centro ||
            links.FingerprintSap!=version.FingerprintSha256 || links.SapBusinessPartner!=s.IdParceiro || links.SapMaterial!=s.Material)
            throw new AcmR57BlockedException("R57_SOURCE_IDENTITY_MISMATCH");
        if(new FugaTES.Aplicacao.Servicos.ContratosSapToledo.ContratoSapToledoCanonicalizer().Canonicalizar(s).FingerprintSha256!=version.FingerprintSha256)
            throw new AcmR57BlockedException("R57_SOURCE_FINGERPRINT_MISMATCH");
        foreach(var v in new[]{s.NumeroContrato,s.Item,s.Centro,s.TipoContrato,s.DescricaoTipoContrato,s.IdParceiro,s.Material,s.UnidCont,s.OperacaoContrato,s.StatusContrato})
            Require(v,160,"R57_INBOUND_REQUIRED_FIELDS");
        if(s.Centro!="3011" || s.TipoContrato!="AC3P" || s.QuantidadeContrato is null or <0)
            throw new AcmR57BlockedException("R57_INBOUND_SCENARIO_INVALID");
        Require(links.CodigoContratoGuardian,20,"R57_CONTRACT_CODE_UNAPPROVED");
        if(s.NumeroContrato.Any(c=>!char.IsAsciiDigit(c)) || links.CodigoContratoGuardian.Any(c=>!char.IsAsciiDigit(c)) ||
            s.NumeroContrato.TrimStart('0')!=links.CodigoContratoGuardian.TrimStart('0') || links.CodigoContratoGuardian.All(c=>c=='0'))
            throw new AcmR57BlockedException("R57_CONTRACT_REPRESENTATION_UNAPPROVED");
        Require(links.CodigoEmissorGuardian,20,"R57_EMITTER_MAPPING_REQUIRED");
        Require(links.CodigoItemGuardian,30,"R57_ITEM_MAPPING_REQUIRED");
        foreach(var v in new[]{links.EstadoGuardian,links.TipoLancamentoGuardian,links.FonteMapeamentos,links.FonteDocumento,links.FontePeso,links.FonteCampoAdicional})
            Require(v,160,"R57_PROVEN_FUNCTIONAL_SOURCE_REQUIRED");
        Require(links.DocumentoOperacao,40,"R57_OPERATION_DOCUMENT_REQUIRED");
        Require(links.NumeroReferencia,10,"R57_REFERENCE_INVALID");
        Require(links.ValorCampoAdicional,50,"R57_ADDITIONAL_VALUE_REQUIRED");
        var weight=links.PesoOrigem.ToString("G29",CultureInfo.InvariantCulture);
        if(links.PesoOrigem<0 || weight.Length>13)throw new AcmR57BlockedException("R57_ORIGIN_WEIGHT_INVALID");
        if(!links.CallbackHomologado || !Uri.TryCreate(links.CallbackOperacional,UriKind.Absolute,out var callback) ||
            callback.Scheme!="https" || !string.IsNullOrEmpty(callback.UserInfo))
            throw new AcmR57BlockedException("R57_CALLBACK_NOT_APPROVED");
        var contract=new ContratoGuardianSet26(links.CodigoContratoGuardian,s.DescricaoTipoContrato!,s.QuantidadeContrato.Value,
            links.EstadoGuardian,0m,links.TipoLancamentoGuardian){CodigoEmissor=links.CodigoEmissorGuardian,CodigoItem=links.CodigoItemGuardian};
        var request=new PreCadastroAcmR57(links.CallbackOperacional,new(0,links.CodigoItemGuardian,links.CodigoEmissorGuardian,
            links.CodigoContratoGuardian,[new(links.DocumentoOperacao,weight)],links.NumeroReferencia,[new(0,links.ValorCampoAdicional)]));
        Validar(request);
        return new(contract,request);
    }

    public static void Validar(PreCadastroAcmR57 request)
    {
        ArgumentNullException.ThrowIfNull(request);var d=request.Dados;
        if(d is null || d.Id!=0)throw new AcmR57BlockedException("R57_REST_ID_INVALID");
        Require(d.CodigoContrato,20,"R57_REST_CONTRACT_REQUIRED");Require(d.CodigoItem,30,"R57_ITEM_MAPPING_REQUIRED");
        Require(d.CodigoEmissor,20,"R57_EMITTER_MAPPING_REQUIRED");Require(d.NumeroReferencia,10,"R57_REFERENCE_INVALID");
        if(d.Documentos is null || d.Documentos.Count!=1 || d.Documentos[0] is null)throw new AcmR57BlockedException("R57_OPERATION_DOCUMENT_REQUIRED");
        Require(d.Documentos[0].Descricao,40,"R57_OPERATION_DOCUMENT_REQUIRED");Require(d.Documentos[0].PesoOrigem,13,"R57_ORIGIN_WEIGHT_INVALID");
        if(!decimal.TryParse(d.Documentos[0].PesoOrigem,NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out var weight) || weight<0)
            throw new AcmR57BlockedException("R57_ORIGIN_WEIGHT_INVALID");
        if(d.CamposAdicionais is null || d.CamposAdicionais.Count!=1 || d.CamposAdicionais[0]?.Numero!=0)
            throw new AcmR57BlockedException("R57_ADDITIONAL_FIELD_INVALID");
        Require(d.CamposAdicionais[0].Valor,50,"R57_ADDITIONAL_VALUE_REQUIRED");
        if(!Uri.TryCreate(request.Callback,UriKind.Absolute,out var cb) || cb.Scheme!="https" || !string.IsNullOrEmpty(cb.UserInfo))
            throw new AcmR57BlockedException("R57_CALLBACK_NOT_APPROVED");
    }
    public static bool RespostaConfere(ProtocoloAcmR57 response,PreCadastroAcmR57 request)
        => response.Id>0 && response.CodigoContrato==request.Dados.CodigoContrato && response.CodigoItem==request.Dados.CodigoItem &&
           response.CodigoEmissor==request.Dados.CodigoEmissor && response.NumeroReferencia==request.Dados.NumeroReferencia &&
           (response.NumeroTicket is null || !string.IsNullOrWhiteSpace(response.NumeroTicket));
    private static void Require(string? value,int max,string code)
    {
        if(string.IsNullOrWhiteSpace(value) || value!=value.Trim() || value.Length>max || value.Any(char.IsControl) ||
           new[]{"NÃO VALIDADO","NAO VALIDADO","PENDENTE"}.Contains(value,StringComparer.OrdinalIgnoreCase))
            throw new AcmR57BlockedException(code);
    }
}
