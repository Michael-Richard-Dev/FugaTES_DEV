namespace FugaTES.Aplicacao.Consultas.ContratosAcm;

public sealed record ContratoAcmLeitura(string? Centro, string NumeroContrato, long Versao,
    DateTime RecebidoEm, string? StatusContrato, string EstadoIntegracao,
    Guid IntegracaoId, string CorrelationId, bool VersaoMaisRecente);

public interface IContratosAcmReadRepository
{
    Task<IReadOnlyList<ContratoAcmLeitura>> ConsultarAsync(string centro, CancellationToken ct);
}

public sealed class ContratosAcmConsulta(IContratosAcmReadRepository repository)
{
    public const string CentroInicial = "3011";
    public Task<IReadOnlyList<ContratoAcmLeitura>> ConsultarAsync(string centro, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(centro)) throw new ArgumentException("Informe o centro.", nameof(centro));
        ct.ThrowIfCancellationRequested();
        return repository.ConsultarAsync(centro.Trim(), ct);
    }
}
