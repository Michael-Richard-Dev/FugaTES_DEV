﻿using System.Net;
using FugaTES.Integracao.SAP.Autenticacao;
using FugaTES.Integracao.SAP.Configuracao;

namespace FugaTES.Integracao.SAP.Http;

// Executor HTTP OData reutilizavel para as capabilities SAP do MVP (SD/MM/ACM).
// Centraliza: montagem de URI com sap-client, GET, CSRF fetch, POST/PATCH fenced com cookies e If-Match/ETag.
// Nenhuma semantica funcional aqui: apenas transporte.
public sealed class SapODataHttpExecutor(
    HttpClient httpClient,
    OpcoesSap opcoes,
    IAutenticacaoSap autenticacao,
    CookieContainer cookieContainer)
{
    public sealed class ConfiguracaoInvalidaException(string message) : Exception(message);

    public Uri ConstruirUri(string path, string? extraQuery = null)
    {
        if (opcoes.BaseUrl is null || !opcoes.BaseUrl.IsAbsoluteUri
            || string.IsNullOrWhiteSpace(opcoes.SapClient) || opcoes.Timeout <= TimeSpan.Zero)
        {
            throw new ConfiguracaoInvalidaException("Configuracao SAP invalida (BaseUrl/SapClient/Timeout).");
        }

        var recurso = new Uri(opcoes.BaseUrl, path);
        var sb = recurso.AbsoluteUri;
        sb += (recurso.Query.Length == 0 ? "?" : "&") + "sap-client=" + Uri.EscapeDataString(opcoes.SapClient!);
        if (!string.IsNullOrWhiteSpace(extraQuery))
        {
            sb += "&" + extraQuery;
        }

        return new Uri(sb, UriKind.Absolute);
    }

    public async Task<SapHttpResposta> ObterAsync(Uri uri, CancellationToken cancellationToken)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(opcoes.Timeout);
        using var request = new HttpRequestMessage(HttpMethod.Get, uri);
        request.Headers.TryAddWithoutValidation("Accept", "application/json");
        await autenticacao.AplicarAsync(request, timeout.Token).ConfigureAwait(false);
        using var response = await httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, timeout.Token).ConfigureAwait(false);
        var body = await response.Content.ReadAsStringAsync(timeout.Token).ConfigureAwait(false);
        return new SapHttpResposta(response.StatusCode, body, LerETag(response));
    }

    // CSRF fetch: GET com X-CSRF-Token: Fetch; retorna o token e captura cookies de sessao.
    public async Task<string> ObterTokenCsrfAsync(Uri uri, CancellationToken cancellationToken)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(opcoes.Timeout);
        using var fetch = new HttpRequestMessage(HttpMethod.Get, uri);
        fetch.Headers.TryAddWithoutValidation("X-CSRF-Token", "Fetch");
        await autenticacao.AplicarAsync(fetch, timeout.Token).ConfigureAwait(false);
        using var response = await httpClient.SendAsync(fetch, HttpCompletionOption.ResponseHeadersRead, timeout.Token).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode)
        {
            throw new SapHttpStatusException("CSRF fetch falhou.", response.StatusCode);
        }

        if (!response.Headers.TryGetValues("X-CSRF-Token", out var tokens) || string.IsNullOrWhiteSpace(tokens.FirstOrDefault()))
        {
            throw new SapHttpStatusException("Token CSRF ausente.", response.StatusCode);
        }

        CapturarCookies(uri, response);
        return tokens.First();
    }

    public async Task<SapHttpResposta> EnviarComCsrfAsync(
        HttpMethod metodo,
        Uri uri,
        HttpContent? conteudo,
        string tokenCsrf,
        string? ifMatch,
        CancellationToken cancellationToken)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(opcoes.Timeout);
        using var request = new HttpRequestMessage(metodo, uri) { Content = conteudo };
        request.Headers.TryAddWithoutValidation("X-CSRF-Token", tokenCsrf);
        request.Headers.TryAddWithoutValidation("Accept", "application/json");
        if (!string.IsNullOrWhiteSpace(ifMatch))
        {
            request.Headers.TryAddWithoutValidation("If-Match", ifMatch);
        }

        var cookies = cookieContainer.GetCookieHeader(uri);
        if (!string.IsNullOrWhiteSpace(cookies))
        {
            request.Headers.TryAddWithoutValidation("Cookie", cookies);
        }

        await autenticacao.AplicarAsync(request, timeout.Token).ConfigureAwait(false);
        using var response = await httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, timeout.Token).ConfigureAwait(false);
        var body = await response.Content.ReadAsStringAsync(timeout.Token).ConfigureAwait(false);
        return new SapHttpResposta(response.StatusCode, body, LerETag(response));
    }

    private void CapturarCookies(Uri uri, HttpResponseMessage response)
    {
        if (!response.Headers.TryGetValues("Set-Cookie", out var values))
        {
            return;
        }

        foreach (var value in values)
        {
            cookieContainer.SetCookies(uri, value);
        }
    }

    private static string? LerETag(HttpResponseMessage response)
    {
        var etag = response.Headers.ETag;
        if (etag is null)
        {
            return null;
        }

        return etag.IsWeak ? "W/" + etag.Tag : etag.Tag;
    }
}

public sealed record SapHttpResposta(HttpStatusCode Status, string Body, string? ETag);

public sealed class SapHttpStatusException(string message, HttpStatusCode statusCode) : Exception(message)
{
    public HttpStatusCode StatusCode { get; } = statusCode;
}
