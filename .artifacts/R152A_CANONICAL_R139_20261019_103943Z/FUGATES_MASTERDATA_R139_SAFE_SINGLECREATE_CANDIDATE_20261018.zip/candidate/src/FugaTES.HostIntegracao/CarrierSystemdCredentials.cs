using System.Net.Http.Headers;
using System.Text;
using FugaTES.Aplicacao.Contratos.Recebimento;
using FugaTES.Integracao.SAP.Autenticacao;
namespace FugaTES.HostIntegracao;

public sealed class CarrierSystemdCredentials(string directory)
{
    public static readonly IReadOnlyList<string> RequiredNames=Array.AsReadOnly(new[]{"carrier-hml-postgres-password","carrier-hml-guardian-email","carrier-hml-guardian-password","carrier-hml-guardian-signature","carrier-hml-sap-user","carrier-hml-sap-password"});
    public static void ValidateName(string name)
    {if(!RequiredNames.Contains(name,StringComparer.Ordinal))throw new CarrierServiceStartupException("CARRIER_LINUX_CREDENTIAL_ID_INVALID");}
    public static void ValidateMode(UnixFileMode mode)
    {if(mode!=UnixFileMode.UserRead)throw new CarrierServiceStartupException("CARRIER_LINUX_CREDENTIAL_PERMISSIONS_INVALID");}
    public string Read(string name)
    {
        ValidateName(name);
        if(!OperatingSystem.IsLinux())throw new CarrierServiceStartupException("CARRIER_LINUX_REQUIRED");
        try
        {
            if(!Path.IsPathFullyQualified(directory)||directory.Contains("/../",StringComparison.Ordinal)||directory.Contains("/./",StringComparison.Ordinal)||new DirectoryInfo(directory).LinkTarget is not null)
                throw new CarrierServiceStartupException("CARRIER_LINUX_CREDENTIAL_DIRECTORY_INVALID");
            var path=Path.Combine(directory,name);var file=new FileInfo(path);
            if(!file.Exists||file.LinkTarget is not null||file.Length is <1 or >16384)throw new CarrierServiceStartupException("CARRIER_LINUX_CREDENTIAL_MISSING_OR_INVALID");
            ValidateMode(File.GetUnixFileMode(path));
            var secret=File.ReadAllText(path,new UTF8Encoding(false,true));
            if(string.IsNullOrWhiteSpace(secret)||secret.Contains('\0'))throw new CarrierServiceStartupException("CARRIER_LINUX_CREDENTIAL_MISSING_OR_INVALID");
            return secret;
        }
        catch(CarrierServiceStartupException){throw;}
        catch{throw new CarrierServiceStartupException("CARRIER_LINUX_CREDENTIAL_UNAVAILABLE");}
    }
    public void ValidateRequired(){foreach(var name in RequiredNames)_=Read(name);}
}

public sealed class CarrierLinuxGuardianCredentials(CarrierLinuxRuntimeBootstrap runtime):ICredenciaisGuardianSet26Provider
{
    public Task<CredenciaisGuardianSet26> ObterAsync(CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        return Task.FromResult(new CredenciaisGuardianSet26(runtime.Credentials.Read("carrier-hml-guardian-email"),runtime.Credentials.Read("carrier-hml-guardian-password"),runtime.Credentials.Read("carrier-hml-guardian-signature")));
    }
}
public sealed class CarrierLinuxSapAuthentication(CarrierLinuxRuntimeBootstrap runtime):IAutenticacaoSap
{
    public Task AplicarAsync(HttpRequestMessage request,CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();var approved=new Uri(runtime.Profile.Sap.BaseUrl);
        if(request.RequestUri is not {Scheme:"https"} endpoint||endpoint.GetLeftPart(UriPartial.Authority)!=approved.GetLeftPart(UriPartial.Authority)||endpoint.UserInfo.Length!=0)
            throw new CarrierServiceStartupException("CARRIER_LINUX_SAP_ORIGIN_INVALID");
        var user=runtime.Credentials.Read("carrier-hml-sap-user");var password=runtime.Credentials.Read("carrier-hml-sap-password");
        request.Headers.Authorization=new AuthenticationHeaderValue("Basic",Convert.ToBase64String(Encoding.UTF8.GetBytes(user+":"+password)));return Task.CompletedTask;
    }
}