using FugaTES.HostIntegracao;

var builder = Host.CreateApplicationBuilder(args);
try
{
    HostIntegracaoComposition.Configurar(builder);
    var host = builder.Build();
    host.Run();
}
catch(Exception ex) when(OperatingSystem.IsLinux() && builder.Configuration["HostIntegracao:Mode"]=="CarrierSync")
{
    // No exception payload, profile path, connection string or secret reaches journald.
    Console.Error.WriteLine(ex is CarrierServiceStartupException failure ? failure.Code : "CARRIER_LINUX_STARTUP_FAILED");
    Environment.ExitCode=1;
}