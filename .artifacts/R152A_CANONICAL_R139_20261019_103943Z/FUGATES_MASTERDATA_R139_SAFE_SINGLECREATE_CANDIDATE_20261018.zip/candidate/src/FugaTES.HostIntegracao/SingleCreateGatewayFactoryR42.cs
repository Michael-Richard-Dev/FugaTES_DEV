﻿using FugaTES.Aplicacao.Transportadoras;
using FugaTES.Integracao.Guardian;
namespace FugaTES.HostIntegracao;

// Fabrica tipada do gateway de escrita do CREATE unitario de transportadora.
// Existe para manter a infraestrutura HTTP FORA da camada WinForms: a UI recebe esta fabrica e
// nunca nomeia, constroi nem possui um cliente HTTP. Este arquivo e o unico ponto novo que
// conhece o transporte, e fica na camada de composicao, que legitimamente o conhece.
public delegate IGuardianCarrierGateway SingleCreateGatewayFactoryR42(
    GuardianCarrierHmlContract contratoComprovado, Func<CarrierWriteAttempt, bool> autorizar);

public static class SingleCreateGatewayCompositionR42
{
    // Fabrica para runtime: liga o contrato HML comprovado e o predicado de autorizacao ao
    // adapter HTTP existente. Nenhuma rota, credencial ou semantica nova e introduzida aqui.
    public static SingleCreateGatewayFactoryR42 Criar(HttpClient http, GuardianHttpOptions options, GuardianTokenClient tokens)
    {
        ArgumentNullException.ThrowIfNull(http);
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(tokens);
        return (contrato, autorizar) =>
        {
            ArgumentNullException.ThrowIfNull(contrato);
            ArgumentNullException.ThrowIfNull(autorizar);
            return new GuardianCarrierSyncAdapter(http, options, tokens, contrato, autorizar);
        };
    }
}
