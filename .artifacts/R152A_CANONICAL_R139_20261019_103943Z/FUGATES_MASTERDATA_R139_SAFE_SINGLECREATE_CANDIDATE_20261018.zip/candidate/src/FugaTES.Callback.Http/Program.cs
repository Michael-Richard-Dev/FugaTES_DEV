using FugaTES.Callback.Http;

var builder = WebApplication.CreateBuilder(args);
var routes = InboundHttpHostComposition.Configurar(
    builder.Services, builder.Configuration, builder.Environment.IsDevelopment());

var app = builder.Build();
HealthEndpoint.Map(app);
if (routes.Callback is { } callback)
{
    if (callback.CorrelationProvider == CallbackHttpOptions.PostgreSqlImplementation)
        GuardianCallbackEndpoint.MapEvento(app, callback.Route);
    else
        GuardianCallbackEndpoint.Map(app, callback.Route);
}
if (routes.SapProductive)
    SapContractInboundEndpoint.MapDurable(app);
if (routes.SapOffline)
    SapContractInboundEndpoint.Map(app);
app.Run();
