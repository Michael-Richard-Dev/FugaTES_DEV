Empty local NuGet feed. Packages used by the recorded build came exclusively from the pre-existing approved cache. No package downloads were performed.
