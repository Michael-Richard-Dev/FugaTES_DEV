# HEFESTO V2 — R135D / SingleCreate transaction boundary

PROJECT=FUGATES  
GATE=FUGATES-MASTERDATA-R135D-SINGLECREATE-COMMIT-CLOSURE  
MODE=SOURCE_ONLY_OFFLINE_NO_WRITES  
RESULT=FOCAL_PATCH_REQUIRED_NOT_IMPLEMENTED

## 1. Input provenance and integrity

The supplied `FUGATES_R135C_R132_SOURCE_HANDOFF(1).zip` has SHA-256 `62DA8691DF2524AD23FC980FFDEADBE8D5CA60C60D006BC5D8D0F5861C410B36`, CRC OK, 7 members. Every one of the six entries declared in `MANIFEST_SHA256.json` matches its recorded SHA-256 (6/6 PASS), including:

| R132 source | SHA-256 | Result |
|---|---|---|
| `reference_original/GuardianSingleCreateUseCaseR31.cs` | `1459751F9D716C1AD60E2684EB7A26DB40FB29DAFDE551704494C7D6F83597DD` | PASS |
| `reference_original/SingleCreateDesktopBindingR41.cs` | `D63D91EB83809F2AA60D564CE54D774F28B7F369420CA6A2134E728FDF33739F` | PASS |
| `reference_original/SingleCreateJournalPolicyR31.cs` | `49E9CDB326B2B22F918AE7DCEB44F38F84A88F1697340E065E5EAAAF9E95362E` | PASS |
| `reference_original/SingleCreateJournalPostgreSqlR31.cs` | `7B67EAE673E55B5EF64696B018964B51205121A5CB41F553F70F068E50D910A3` | PASS |

`MANIFEST_SHA256.json` *reports* the originating Gaia R132 ZIP SHA-256 `C9A7A8EA21444BFBAE5FCE2CEAF5575040DD668484BAE7E7E8161C4D80E67B2E`. This report cannot independently verify the origin ZIP because it was not provided; the supplied handoff bytes and manifest have been verified.

The current Windows source evidence `FUGATES_R135_STATIC_SOURCE_EVIDENCE_20261018_091502.txt` was reviewed from indexed Project file content, not from live Windows access. It enumerates 262 source files and reports `SingleCreateDesktopBindingR41.cs`, `SingleCreateJournalPostgreSqlR31.cs`, and `SingleCreateGatewayFactoryR42.cs` absent from that scanned worktree. The separate current-composition R135B Codex evidence is explicitly PENDING and not in the reviewed inputs. Absence in a worktree scan does not prove absence from a deployed binary.

## 2. Source findings (file:lines)

- `reference_original/SingleCreateDesktopBindingR41.cs:66-69`: `BindAsync` receives `NpgsqlDataSource source` from its caller; does not create or configure datasource.
- `...BindingR41.cs:75-98`: gating HML and `Carrier:SingleCreate:Enabled`; `JournalReadyAsync(source)` then `new SingleCreateJournalPostgreSqlR31(source, clock)`, and `prepared.CreateUseCase(reader,writer,journal,gate,clock)`; proves R132 reference wiring, not actual current Desktop invocation.
- `...BindingR41.cs:39-49`: `JournalReadyAsync` opens a connection, explicitly begins a READ-ONLY transaction and awaits `CommitAsync`. This is **preflight only**, not the PREPARED reservation transaction.
- `reference_original/SingleCreateJournalPostgreSqlR31.cs:10,32-55`: journal receives shared `NpgsqlDataSource`; `TryPrepareAsync` calls `source.CreateCommand(PrepareSql)` then `ExecuteNonQueryAsync`; returns true when affected=1. No `OpenConnectionAsync`, `BeginTransactionAsync`, `CommitAsync` in this reservation method; no explicit assurance against ambient `TransactionScope` auto-enlistment.
- `...JournalPostgreSqlR31.cs:17-23`: atomic insert guarded with NOT EXISTS, with DB uniqueness relied upon for concurrency. These predicates do not prove committed durability.
- `...JournalPostgreSqlR31.cs:47-55`: unique/exclusion conflict returns false; other failures propagate, resulting in fail-closed `INDETERMINATE` at use-case level.
- `...JournalPostgreSqlR31.cs:57-72`: `ConfirmAsync` is a separate later UPDATE; it cannot serve as proof that PREPARED committed before Guardian HTTP.
- `reference_original/GuardianSingleCreateUseCaseR31.cs:57-63`: awaited `TryPrepareAsync` precedes writer `GravarAsync`. Failure and false return stop dispatch; positive return permits writer after gate recheck. There is no additional committed-reservation confirmation.
- `...UseCaseR31.cs:64-73`: HTTP 200/code check and `ConfirmAsync` occur after dispatch; its failure leads to indeterminate, no automatic retry specified.
- Current source evidence `src/FugaTES.WinForms/Runtime/DesktopRuntime.cs:18-25`: carrier datasource created from validated runtime connection string; line 21 builds options for read-only override and application name, but no demonstrated `Enlist=false`.
- Current source evidence `src/FugaTES.WinForms/Transportadoras/CarrierDesktopComposition.cs:59-95`: creates an independent `SincronizarTransportadoras` motor via `CreateCarrierStore`; does **not** demonstrate invocation of the R132 `SingleCreateDesktopBindingR41.BindAsync` in the scanned worktree.
- Current source evidence `src/FugaTES.Aplicacao/Transportadoras/SincronizarTransportadoras.cs:122-130`: other carrier dispatch through `guardian.GravarAsync`, separate from SingleCreate R31. Current runtime enablement/reachability and its commit boundary require specific evidence.

## 3. Decision on transaction guarantees

`R135D_R132_SOURCE=PASS` for manifest/source integrity. The R132 code lacks dedicated non-enlisted datasource configuration and explicit PREPARED commit. With **no ambient transaction**, PostgreSQL's normal implicit transaction would ordinarily complete before a successful standalone command return, subject to server durability settings; however, that is a conditional scenario, **not** proof of the effective call path. With an ambient transaction and default/enabled Npgsql enlistment, command execution and an affected-row count can precede the ambient commit; returning true may therefore allow Guardian POST before committed PREPARED. The actual ambient-transaction state and Npgsql connection-string enlistment for the effective R132 runtime have not been shown.

The use-case handler already prevents dispatch on thrown/indeterminate prepare; a failure **after** a successful `ExecuteNonQueryAsync` but **before** ambient commit (or an ambient rollback) is the unproven gap. Physical post-crash durability also depends on PostgreSQL settings such as `synchronous_commit`, `fsync` and storage guarantees, none inspected in this gate.

## 4. Minimal patch specification (not implemented)

1. In the current Desktop composition, after validating the existing HML connection identity, construct and own **a separate journal `NpgsqlDataSource`** using `NpgsqlConnectionStringBuilder` with `Enlist=false`. Do not mutate the general carrier pool or overwrite runtime configuration; close/dispose this datasource with the session. Never log connection string/credentials. Preserve `Carrier:SingleCreate:Enabled=false` during development.
2. Pass the **dedicated non-enlisted** source into `SingleCreateDesktopBindingR41.BindAsync`, retaining the existing HML, approval, signature, journal ACL and writer gates. Ensure no hidden fallback to the shared source if the dedicated source fails.
3. Change **only** `SingleCreateJournalPostgreSqlR31.TryPrepareAsync`'s transaction boundary: explicitly `OpenConnectionAsync`, `BeginTransactionAsync(IsolationLevel.ReadCommitted,...)`, execute exactly the existing `PrepareSql` on that connection **and transaction**; interpret affected row count with the existing `SingleCreateJournalPolicyR31`; when 1, `await transaction.CommitAsync(...)` must **complete successfully before returning true**. For 0 or uniqueness conflict, return false after rollback/disposal; for any other or ambiguous commit outcome, throw/propagate so use case returns `CREATE_PREPARE_OUTCOME_UNKNOWN` and **does not dispatch**. Never convert a commit exception into success or allow an automatic blind retry.
4. Preserve table schema, UNIQUE guards, statuses, payload digest, immutable attempt ID, R31/R41 gate logic, and `ConfirmAsync` post-HTTP flow. Do not conflate the journal's preflight READ ONLY commit with the reservation commit.
5. Explicitly review or keep the separate `SincronizarTransportadoras` CREATE/UPDATE route disabled until its distinct durable-attempt boundary and enablement are verified; the SingleCreate patch does not secure a different dispatcher.
6. Before production/HML release, independently check actual deployed Desktop composition, package hashes, configured `Enlist`, ambient scope propagation, and PostgreSQL server durability parameters; do not claim post-crash guarantee from fake-based tests.

## 5. Future offline tests, no live I/O

| Test | Expected |
|---|---|
| Gate `SingleCreate:Enabled=false` | No binding and zero POST |
| No journal / failed preflight | No binding and zero POST |
| PREPARED affected=1 and Commit completes | Only then writer may be invoked once, given all other gates |
| INSERT rejected/affected=0 | Block and zero POST |
| Concurrent attempts same BP or Guardian code | At most one PREPARED winner; loser blocked, no duplicate dispatch |
| Same attempt replay / already PREPARED | No second POST without reconciliation |
| `ExecuteNonQueryAsync` throws, cancels, times out | Indeterminate/blocked and zero POST |
| Commit throws, timeout, cancellation, connection lost before acknowledgement | Indeterminate and zero POST; reconcile before any retry |
| Outer `TransactionScope` rolled back | Non-enlisted journal commit remains independent; command returns success only after own commit; verify using isolated harness, not a live DB |
| Gate revoked between prepare and dispatch | No POST, PREPARED remains for reconciliation |
| Accepted Guardian response followed by `ConfirmAsync` failure | Result indeterminate and no blind retry |
| Separate `SincronizarTransportadoras` | Assert route is independently gated; do not misclassify as R31 |

Mocks prove control flow only, not physical PostgreSQL COMMIT or durability. Real DB integrity/crash tests require a *new* explicit authorization.

## 6. Handoff

```text
R135D_R132_SOURCE=PASS
R135D_CURRENT_COMPOSITION=BLOCKED
R135D_TRANSACTION_ISOLATION=BLOCKED
R135D_COMMIT_BEFORE_HTTP=BLOCKED
R135D_ALTERNATE_DISPATCH=BLOCKED
R135D_PATCH_REQUIRED=YES
R135D_PATCH_SPECIFICATION=READY
FIRST_CREATE_READY=NO
DATABASE_CONNECTIONS=0
DATABASE_WRITES=0
EXTERNAL_POSTS=0
SOURCE_CHANGES=0
FIRST_BLOCKER=CURRENT_R135B_DESKTOP_COMPOSITION_AND_ENLISTMENT_UNAVAILABLE;R132_PREPARED_RESERVATION_HAS_NO_EXPLICIT_COMMIT
NEXT_HANDOFF=HERA_V3
```
