R139 — SOURCE CANDIDATE / REVIEW ONLY / NOT A PUBLISHED RELEASE

Leia HANDOFF_HERA_HERMES_R139.md antes de utilizar o material.

candidate/ contém o fechamento dos fontes copiados e o delta implementado, sem perfis privados.
baseline-changed-files/ contém os oito fontes anteriores, para comparação.
R139_MINIMAL_REVIEW.patch normaliza UTF-8 BOM/EOL para revisão; os bytes autoritativos são os fontes/manifests.
SOURCE_CHANGE_MATRIX.json identifica todos os arquivos/métodos alterados e hashes anterior/posterior.
qa/ contém TRX/logs finais e o histórico RED/erros de recursos, preservado.
BUILD_OUTPUT_HASHES.json identifica os binários compilados localmente, que não foram publicados nem incluídos neste pacote.
reference/ contém a especificação R135D e evidências pequenas de procedência R135B/R132/R114.

O build validado é do projeto WinForms e suas referências, não de toda a solução histórica.
FugaTES.slnx é o marcador original necessário a testes de inspeção de arquivos; ele referencia outros projetos históricos não incluídos como suítes executadas.
O NuGet.Offline.Config é exclusivamente de build local, sem fontes HTTP/segredos. Ajustar apenas a localização do cache de pacotes para outro ambiente de QA não homologa runtime.

Nenhum FugaTES.runtime.json/FugaTES.carrier.json operacional está presente.
Não criar valores de banco, role, porta, assinatura, callback ou aprovação por inferência.
Não iniciar o executável, o Host ou workers. Não executar DB/HTTP ou publish para repetir o QA deste pacote.

Resultados: 31 R139 + 74 R105 focal + 8 R41 focal = 113 PASS; três casos antigos excluídos explicitamente no QA_SUMMARY.json.
PHYSICAL_COMMIT_PROVEN=NO. Identidade física MasterData HML e journal: PENDING_PHYSICAL_VALIDATION.
